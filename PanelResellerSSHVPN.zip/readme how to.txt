===============================================================================

Readme // ForNesia
Special Thx for script by Setiawan Jodi // jodisetiawan@fisip-untirta.ac.id
Edited fornesiafreak/fornesia.com

https://www.fornesia.com
https://www.imadenews.com

===============================================================================

Folder Screenshoot Chmod 777
Folder Config Chmod 777

===============================================================================


Edit seting

administrator/tambah-member.php
administrator/pesan.php
/administrator/informasi.php
administrator/inbox.php
administrator/base/schema.php
/aktifasi/index.php
lostpassword.php
kontak.php
function.php
function2.php
tambah-saldo.php
daftar.php 

Edit Promo EMail

administrator/email/promosi.php
administrator/email/expired-akun.php
===============================================================================

// DATABASE

upload panelReseller.sql ke database lewat phpmyadmin

Edit Database config di

/asset/css/config.php


===============================================================================
Admin Login

username: admin
password: fornesia123


===============================================================================