<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Detail Akun</title>
</head>

<body>



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
		
        <div class="warper container-fluid">
			
			<div class="page-header"><center><h3><i class="fa fa-fw fa-terminal"></i> Detail Akun</h3></center></div>

			<div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php
						$qdata = "SELECT * FROM akun WHERE id = :id LIMIT 0,1";
						$tdata = $databaseConnection->prepare($qdata);
						$tdata->bindParam(':id', $_REQUEST['id']);
						$tdata->execute();
						$cdata = $tdata->fetchAll();
						foreach ($cdata as $cdat) {
							$ptgl = $cdat['expiredate'];
					?>
					<?php
						$qdata1 = "SELECT * FROM server WHERE host = :host LIMIT 0,1";
						$tdata1 = $databaseConnection->prepare($qdata1);
						$tdata1->bindParam(':host', $cdat['host']);
						$tdata1->execute();
						$cdata1 = $tdata1->fetchAll();
					?>
					<?php
						$qdata2 = "SELECT * FROM member WHERE email = :pengguna LIMIT 0,1";
						$tdata2 = $databaseConnection->prepare($qdata2);
						$tdata2->bindParam(':pengguna', $menuusername);
						$tdata2->execute();
						$cdata2 = $tdata2->fetchAll();
						foreach ($cdata2 as $cdat2) {
							$pengguna2 = $cdat2['balance1'];
						}
					?>
					<div class="tl-content">
						<div class="panel panel-default">
							<div class="panel-heading"><i class="fa fa-terminal fa-fw"></i> Detail Akun</div>
							<div class="panel-body">
								Server : <?php echo $cdat['namaserver']; ?>
								<hr>
								Host : <?php echo $cdat['host']; ?>
								<hr>
								Username : <?php echo $cdat['uservpn'];?>
								<hr>
								Password : <?php echo $cdat['passvpn']; ?>
								<hr>
								Lokasi : <?php echo $cdat['lokasi']; ?>
								<hr>
								ISP : <?php echo $cdat['isp']; ?>
								<hr>
								Port OpenSSH : <?php echo $cdat['openssh']; ?>
								<hr>
								Port Dropbear : <?php echo $cdat['dropbear']; ?>
								<hr>
								Port Squid : <?php echo $cdat['squid']; ?>
								<hr>
								Port TCP/UDP : <?php echo $cdat['ovpn']; ?>
								<hr>
								Link Config : <?php echo $cdat['link_config']; ?>
								<hr>
								Expired : <?php echo $cdat['expiredate'];?>
								<hr>
								Harga : <?php echo $cdat['dari'];?>
								<hr>
								Catatan : <?php echo $cdat['catatan']; ?>
								<?php } ?>
								<hr>
									<div class="form-group">
										<a onclick="history.back(-1)">
											<button type="button" class="btn btn-info" id="resetBtn">
												<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
											</button>
										</a>
									</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
        
        <?php include 'base/footer.php'; ?>
    
    </section>
    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>