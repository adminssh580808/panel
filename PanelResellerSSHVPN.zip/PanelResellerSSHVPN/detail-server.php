<?php
ob_start();
session_start();
error_reporting(0);
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Detail Server</title>
</head>

<body>



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>

        <div class="warper container-fluid">
		
			<div class="page-header"><center><h3><i class="fa fa-fw fa-database"></i> Detail Server</h3></center></div>
			
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
                	<div class="panel panel-default">
						<?php
						function getStatus($ip,$port){
						$socket = @fsockopen($ip, $port, $errorNO, $errorstr, 3);
						if(!$socket) return "<font color=#FF0000>Offline</font>";
						else return "<font color=#449D44>Online</font>";
						}
						
                        $qtampil = "SELECT * FROM server WHERE idserver = :idserver";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':idserver', $_REQUEST['idserver']);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
							$link_config = $serv['link_config'];
                        ?>
                        <div class="panel-heading"><i class="fa fa-fw fa-database"></i> <?php echo $serv['namaserver'];?></div>
						<div class="panel-body" style="padding:0">
							<table class="table">
								<tbody>
									<tr>
										<td>Status Server</td>
										<td><?php echo getStatus($serv['host'], "22");?></td>
									</tr>
									<tr>
										<td>Lokasi</td>
										<td><?php echo $serv['lokasi']; ?></td>
									</tr>
									<tr>
										<td>ISP</td>
										<td><?php echo $serv['isp']; ?></td>
									</tr>
									<tr>
										<td>Harga Member</td>
										<td><?php echo number_format($serv['harga1'], 0 , '' , '.' ) ; ?></td>
									</tr>
									<tr>
										<td>Harga Reseller</td>
										<td><?php echo number_format($serv['harga2'], 0 , '' , '.' ) ; ?></td>
									</tr>
									<tr>
										<td>OpenSSH</td>
										<td><?php echo $serv['openssh']; ?></td>
									</tr>
									<tr>
										<td>Dropbear</td>
										<td><?php echo $serv['dropbear']; ?></td>
									</tr>
									<tr>
										<td>Squid</td>
										<td><?php echo $serv['squid']; ?></td>
									</tr>
									<tr>
										<td>TCP/UDP</td>
										<td><?php echo $serv['ovpn']; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
						<?php } ?>
						<div class="panel-footer">
							<a onclick="history.back(-1)" class="btn btn-info" title="Kembali">
								<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
							</a>
						</div>
                    </div>
				</div>
		
    </section>
    <section class="content">
		<?php include 'base/footer.php'; ?>
	</section>

    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>