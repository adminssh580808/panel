<?php
ob_start();
session_start();
include 'asset/css/config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Daftar Server</title>
</head>

<body>	



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
                
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-fw fa-database"></i> Daftar Server</h3></center></div>
				<?php
				function getStatus($ip, $port){
					$socket = @fsockopen($ip, $port, $errorNO, $errorstr, 3);
					if(!$socket) return "<font color=#FF0000>Offline</font>";
					else return "<font color=#449D44>Online</font>";
					}
				
				$qtserver = "SELECT * FROM server WHERE status2 = :status2";
				$tserver = $databaseConnection->prepare($qtserver);
				$status2 = 'Tersedia';
				$tserver->bindParam(':status2', $status2);
				$tserver->execute();
				$server = $tserver->fetchAll();
				foreach ($server as $serv) {
				?>
			
				<div class="col-sm-6 col-md-4 col-lg-4">
				<div class="row">

					<div class="panel panel-default">
						<div class="panel-heading text-center">
							<?php echo $serv['namaserver'];?>
							<br><small><?php echo number_format($serv['harga2'], 0 , '' , '.' ) ; ?></small>
						</div>
						<div class="panel-body" style="padding:0">
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td>Status</td>
										<td><?php echo getStatus($serv['host'], "22");?></td>
									</tr>
									<tr>
										<td>Port SSH</td>
										<td><?php echo $serv['openssh']; ?></td>
									</tr>
									<tr>
										<td>Dropbear</td>
										<td><?php echo $serv['dropbear']; ?></td>
									</tr>
									<tr>
										<td>Squid</td>
										<td><?php echo $serv['squid']; ?></td>
									</tr>
									<tr>
										<td>TCP/UDP</td>
										<td><?php echo $serv['ovpn']; ?></td>
									</tr>
									<tr>
										<td>Lokasi</td>
										<td><?php echo $serv['lokasi']; ?></td>
									</tr>
									<tr>
										<td>ISP</td>
										<td><?php echo $serv['isp']; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="panel-footer text-center">
							<a href="buat-akun-reseller.php?idserver=<?php echo $serv['idserver']; ?>" class="btn btn-primary" title="Beli Akun">
								<i class="fa fa-cart-plus fa-fw"></i>
							</a>
							<a href="http://<?php echo $serv['link_config']; ?>" class="btn btn-success" <?php
								if($serv['link_config'] == '') {
								 echo 'disabled="yes"';
								} else {
								echo 'target="_blank"';
								}
								?> title="Config OVPN">
								<i class="fa fa-download fa-fw"></i>
							</a>
							<a href="detail-server.php?idserver=<?php echo $serv['idserver']; ?>" class="btn btn-info" title="Detail Server">
								<i class="fa fa-info fa-fw"></i>
							</a>
							<a href="akun-server-reseller.php?idserver=<?php echo $serv['idserver']; ?>" class="btn btn-warning" title="Status Server">
								<i class="fa fa-search fa-fw"></i>
							</a>
						</div>
					</div>
					</div>
                </div>
				<?php } ?>
			</div>
        </div>

    </section>
	
	<section class="content">
		<?php include 'base/footer.php'; ?>
	</section>
	
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>