<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Download Config</title>
</head>

<body>	



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-fw fa-download"></i> Download Config</h3></center></div>
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-fw fa-download"></i> Download Config</div>
						<div class="panel-body">
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
								<thead>
									<tr>
										<th><center>Tanggal Upload</center></th>
										<th><center>Nama Config</center></th>
										<th><center>Download</center></th>
									</tr>
								</thead>
								<tbody>
									<?php
									$qtserver = "SELECT * FROM config";
									$tserver = $databaseConnection->prepare($qtserver);
									$tserver->execute();
									$server = $tserver->fetchAll();
									foreach ($server as $serv) {
									?>
									<tr class="odd gradeX">
										<td><?php echo $serv['tgl']; ?></td>
										<td><?php echo $serv['nama_config']; ?></td>
										<td><center><a class="btn btn-success" href="config/<?php echo $serv['config']; ?>">Download</a></center></td>
									 </tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
        </div>
		
		<?php include 'base/footer.php'; ?>
    
    </section>
    
    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>