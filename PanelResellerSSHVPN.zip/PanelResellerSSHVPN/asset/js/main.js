
$(function() {
    $('form > button').click(function(e){
        e.preventDefault();
        var selectedServer = ($('form select').val());
        if (selectedServer === '') {
            swal(
              'Server Belum Dipilih',
              'Silahkan pilih server terlebih dahulu',
              'error'
            )
        } else { 
            var $this = $(this);
            $this.button('loading');
            $('.container .well').remove();
            $.post( $('form').attr('action'), { selected_server: selectedServer })
            .done(function(data) {
                console.log(data);
                if (data === '500') {
                    swal(
                      'Gagal!',
                      'Terjadi kesalahan server, silahkan coba lain waktu',
                      'error'
                    )
                } else {
                    swal(
                      'Selamat!',
                      'User trial anda berhasil dibuat',
                      'success'
                    )
                    $('.container').append('<div class="well well-lg">'+data+'</div>');
                }
             })
            .fail(function() {
                swal(
                  'Gagal!',
                  'Terjadi kesalahan server, silahkan coba lain waktu',
                  'error'
                )
             })
             .always(function() {
                $this.button('reset');
             });
        }
        
    });
});