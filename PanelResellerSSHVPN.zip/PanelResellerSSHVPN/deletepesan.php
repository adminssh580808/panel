<?php
ob_start();
session_start();
include 'asset/css/config.php';

    $tampil = "SELECT * FROM saran WHERE id = :id";
    $stampil = $databaseConnection->prepare($tampil);
    $stampil->bindParam(':id', $_GET['id']);
    $stampil->execute();
    $server = $stampil->fetchAll();
    foreach ($server as $serv) {
		
	$pathfile = "../inbox/" . $serv['file'];
	unlink($pathfile);

	$hapus = "DELETE FROM saran WHERE id = :id";
	$rhapus = $databaseConnection->prepare($hapus);
	$rhapus->bindParam(':id', $_GET['id']);
	
	if($result = $rhapus->execute()){
		echo "<script language = 'javascript'>
		alert('Sukses Hapus Pesan!');
		window.location = 'send.php?action=done';
		</script>
		";
	} else {
		echo "<script language = 'javascript'>
        alert('Failed!');
        window.location = send.php';
        </script>
        ";
	}
}
?>
