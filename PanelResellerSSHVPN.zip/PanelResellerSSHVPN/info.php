<?php
var_dump(extension_loaded('ssh2'));
?>