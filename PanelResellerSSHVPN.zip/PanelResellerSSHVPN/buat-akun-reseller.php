<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);
$tgl = date('Y-m-d');
$waktu1 = date('Y-m-d H:i:s');
$habis1 = date('Y-m-d', strtotime($tgl. ' + 30 days'));
$habis2 = date('Y-m-d', strtotime($tgl. ' + 60 days'));
$habis3 = date('Y-m-d', strtotime($tgl. ' + 90 days'));
$habis4 = date('Y-m-d', strtotime($tgl. ' + 120 days'));
$habis5 = date('Y-m-d', strtotime($tgl. ' + 150 days'));
$habis6 = date('Y-m-d', strtotime($tgl. ' + 180 days'));
$habis7 = date('Y-m-d', strtotime($tgl. ' + 210 days'));
$habis8 = date('Y-m-d', strtotime($tgl. ' + 240 days'));
$habis9 = date('Y-m-d', strtotime($tgl. ' + 270 days'));
$habis10 = date('Y-m-d', strtotime($tgl. ' + 300 days'));
$habis11 = date('Y-m-d', strtotime($tgl. ' + 330 days'));
$habis12 = date('Y-m-d', strtotime($tgl. ' + 360 days'));

$qdariserver = "SELECT * FROM server WHERE idserver = :idserver";
$dariserver = $databaseConnection->prepare($qdariserver);
$dariserver->bindParam(':idserver', $_REQUEST['idserver']);
$dariserver->execute();

while($tampilserver = $dariserver->fetch(PDO::FETCH_OBJ)){

if(isset($_POST['enter'])) {
	$dari = $_POST['dari'];
	$uservpn = $_POST['uservpn'];
	$passvpn = $_POST['passvpn'];
	$idserver = $tampilserver->idserver;
	$host = $tampilserver->host;
	$lokasi = $tampilserver->lokasi;
	$isp = $tampilserver->isp;
	$openssh = $tampilserver->openssh;
	$dropbear = $tampilserver->dropbear;
	$squid = $tampilserver->squid;
	$ovpn = $tampilserver->ovpn;
	$link_config = $tampilserver->link_config;
	$catatan = $tampilserver->catatan;
	$type = '/bin/false -m';
	$username = $_POST['namauservpn'];
	$saldo = $_POST['saldo'];
	$kode = $_POST['kode'];
	//Harga Akun
	$harga1 = $tampilserver->harga2;
	$harga2 = $harga1*2;
	$harga3 = $harga1*3;
	$harga4 = $harga1*4;
	$harga5 = $harga1*5;
	$harga6 = $harga1*6;
	$harga7 = $harga1*7;
	$harga8 = $harga1*8;
	$harga9 = $harga1*9;
	$harga10 = $harga1*10;
	$harga11 = $harga1*11;
	$harga12 = $harga1*12;
	//Total
	$total1 = $saldo-$harga1;
	$total2 = $saldo-$harga2;
	$total3 = $saldo-$harga3;
	$total4 = $saldo-$harga4;
	$total5 = $saldo-$harga5;
	$total6 = $saldo-$harga6;
	$total7 = $saldo-$harga7;
	$total8 = $saldo-$harga8;
	$total9 = $saldo-$harga9;
	$total10 = $saldo-$harga10;
	$total11 = $saldo-$harga11;
	$total12 = $saldo-$harga12;
	//Kurang
	$kurang1 = $saldo<$harga1;
	$kurang2 = $saldo<$harga2;
	$kurang3 = $saldo<$harga3;
	$kurang4 = $saldo<$harga4;
	$kurang5 = $saldo<$harga5;
	$kurang6 = $saldo<$harga6;
	$kurang7 = $saldo<$harga7;
	$kurang8 = $saldo<$harga8;
	$kurang9 = $saldo<$harga9;
	$kurang10 = $saldo<$harga10;
	$kurang11 = $saldo<$harga11;
	$kurang12 = $saldo<$harga12;
	$habis = $_POST['habis'];
	$namaserver = $tampilserver->namaserver;
	//Log
	$usernamelog = $_POST['namauservpn'];
	$namaserverlog = $tampilserver->namaserver;
	$uservpnlog = $_POST['uservpn'];
	$habislog = $_POST['habis'];
	$darilog = $_POST['dari'];
	$kodelog = $_POST['kode'];
	$waktulog = $_POST['waktu'];
	
	$connection = ssh2_connect($tampilserver->host, 22);
	$qorder = "SELECT uservpn, host FROM akun WHERE uservpn = :uservpn AND host = :host";
	$order = $databaseConnection->prepare($qorder);
	$order->bindParam(':uservpn', $uservpn);
	$order->bindParam(':host', $host);
	$order->execute();
	
	if($order->rowCount() > 0){
		$gantiusername = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Username : <b>'.$uservpn.'</b> sudah digunakan.</p>
			<hr>
			<p class="mb-0">Silahkan ganti username dengan yang berbeda.</p>
			</div>
		';
		}
		
		elseif ($habis == "Pilih Masa Aktif") {
			$pilih = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Masa Aktif Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
		}

		//360 Hari
		elseif ($habis == $habis12) {
			if ($kurang12) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '360 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total12);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis12.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//330 Hari
		elseif ($habis == $habis11) {
			if ($kurang11) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '330 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total11);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis11.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//300 Hari
		elseif ($habis == $habis10) {
			if ($kurang10) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '300 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total10);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis10.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//270 Hari
		elseif ($habis == $habis9) {
			if ($kurang9) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '270 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total9);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis9.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//240 Hari
		elseif ($habis == $habis8) {
			if ($kurang8) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '240 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total8);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis8.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//210 Hari
		elseif ($habis == $habis7) {
			if ($kurang7) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '210 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total7);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis7.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//180 Hari
		elseif ($habis == $habis6) {
			if ($kurang6) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '180 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total6);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis6.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//150 Hari
		elseif ($habis == $habis5) {
			if ($kurang5) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '150 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total5);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis5.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//120 Hari
		elseif ($habis == $habis4) {
			if ($kurang4) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '120 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total4);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis4.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//90 Hari
		elseif ($habis == $habis3) {
			if ($kurang3) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '90 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total3);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis3.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//60 Hari
		elseif ($habis == $habis2) {
			if ($kurang2) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '60 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total2);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis2.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}

		}

		//30 Hari
		else {
			if ($kurang1) {
				$saldokurang = '
				<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
				<p>Saldo Anda tidak cukup untuk membuat Akun.</p>
				<hr>
				<p class="mb-0">Silahkan <a href="tambah-saldo.php">Tambah saldo</a> Anda.</p>
				</div>
			';
			}
			elseif (ssh2_auth_password($connection, 'root', $tampilserver->password)) {
				$result = ssh2_exec($connection, "useradd -e `date -d '30 days' +'%Y-%m-%d'` $uservpn -s $type; { echo $passvpn; echo $passvpn; } | passwd $uservpn; usermod -c $username $uservpn");
				
				//simpan 
				$qsimpanakun = "INSERT INTO akun SET idserver = :idserver, namaserver = :namaserver, host = :host, uservpn = :uservpn, passvpn = :passvpn, lokasi = :lokasi, isp = :isp, openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn, link_config = :link_config, catatan = :catatan, expiredate = :expiredate, dari = :dari, kode = :kode, username = :username";
				$simpanakun = $databaseConnection->prepare($qsimpanakun);
				$simpanakun->bindParam(':idserver', $idserver);
				$simpanakun->bindParam(':namaserver', $namaserver);
				$simpanakun->bindParam(':host', $host);
				$simpanakun->bindParam(':uservpn', $uservpn);
				$simpanakun->bindParam(':passvpn', $passvpn);
				$simpanakun->bindParam(':lokasi', $lokasi);
				$simpanakun->bindParam(':isp', $isp);
				$simpanakun->bindParam(':openssh', $openssh);
				$simpanakun->bindParam(':dropbear', $dropbear);
				$simpanakun->bindParam(':squid', $squid);
				$simpanakun->bindParam(':ovpn', $ovpn);
				$simpanakun->bindParam(':link_config', $link_config);
				$simpanakun->bindParam(':catatan', $catatan);
				$simpanakun->bindParam(':expiredate', $habis);
				$simpanakun->bindParam(':dari', $dari);
				$simpanakun->bindParam(':kode', $kode);
				$simpanakun->bindParam(':username', $username);
				$simpanakun->execute();
				
				//history
				$qsimpanakun2 = "INSERT INTO akunlog SET username = :username, namaserver = :namaserver, uservpn = :uservpn, expiredate = :expiredate, dari = :dari, kode = :kode, waktu = :waktu";
				$simpanakun2 = $databaseConnection->prepare($qsimpanakun2);
				$simpanakun2->bindParam(':username', $usernamelog);
				$simpanakun2->bindParam(':namaserver', $namaserverlog);
				$simpanakun2->bindParam(':uservpn', $uservpnlog);
				$simpanakun2->bindParam(':expiredate', $habislog);
				$simpanakun2->bindParam(':dari', $darilog);
				$simpanakun2->bindParam(':kode', $kodelog);
				$simpanakun2->bindParam(':waktu', $waktulog);
				$simpanakun2->execute();
				
				//update
				$qubahsaldo = "UPDATE member SET balance2 = :balance2 WHERE email = :email";
				$ubahsaldo = $databaseConnection->prepare($qubahsaldo);
				$ubahsaldo->bindParam(':balance2', $total1);
				$ubahsaldo->bindParam(':email', $username);
				$ubahsaldo->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Berhasil!</h4>
					<p>Server : '.$namaserver.'</p>
					<p>IP Adderess : '.$host.'</p>
					<p>Username : '.$uservpn.'</p>
					<p>Password : '.$passvpn.'</p>
					<p>Masa Aktif : '.$habis1.'</p>
					<p>Lokasi : '.$lokasi.'</p>
					<p>ISP : '.$isp.'</p>
					<p>Port OpenSSH : '.$openssh.'</p>
					<p>Port Dropbear : '.$dropbear.'</p>
					<p>Port Squid : '.$squid.'</p>
					<p>Port VPN : '.$ovpn.'</p>
					<p>Config OVPN : '.$link_config.'</p>
					<hr>
					<p class="mb-0">'.$catatan.'</p>
					</div>
				';
			}
			else {
				$gagal = '
					<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
					<p>Ada masalah pada server.</p>
					<hr>
					<p class="mb-0">Silahkan hubungi <a href="kontak.php">Admin</a>.</p>
					</div>
				';
				}
		}

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<!-- Title -->
<title>Buat Akun</title>
</head>

<body>



	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>

        <div class="warper container-fluid">
			<?php 
			if ($tampilserver->status2 == "Tersedia") {
			?>
			<div class="page-header"><center><h3><i class="fa fa-fw fa-database"></i> <?php echo $tampilserver->namaserver; ?></h3></center></div>
            <div class="row">
			<div class="col-md-6" style="padding-left:0;padding-right:0">
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Saldo Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo number_format($deposit['balance2'], 0 , '' , '.' ); ?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Harga Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-cart-plus fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo number_format($tampilserver->harga2, 0 , '' , '.' );?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Catatan</center></div>
						<div class="panel-body">
							<div class="form-group">
								<center><b>Dengan melakukan Pembelian/Pembuatan Akun berarti Anda menyetujui Peraturan Server Kami.</b><hr></center>
							</div>
						</div>
					</div>
				</div>
			</div>
            	<div class="col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gantiusername)){ echo $gantiusername; } ?>
					<?php if(isset($saldokurang)){ echo $saldokurang; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
					<?php if(isset($pilih)){ echo $pilih; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><center>Buat Akun</center></div>
                        <div class="panel-body">
                        	<form  method="post" action="">
							<input type="hidden" name="namauservpn" value="<?php echo $menuusername; ?>" readonly />
							<input type="hidden" name="dari" value="Reseller" readonly />
							<input type="hidden" name="kode" value="1" readonly />
							<input type="hidden" name="waktu" value="<?php echo $waktu1; ?>" readonly />
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" name="uservpn" placeholder="Username" required />
								</div>
							</div>
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-key fa-fw"></i></span>
									<input type="text" class="form-control" name="passvpn" placeholder="Password" required />
								</div>
							</div>
                            <div class="form-group">
								<div class="input-group">
									<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-calendar fa-fw"></i></span>
									<select type="text" class="form-control" name="habis">
										<option>Pilih Masa Aktif</option>
										<option value="<?php echo $habis1; ?>">30 Hari</option>
										<option value="<?php echo $habis2; ?>">60 Hari</option>
										<option value="<?php echo $habis3; ?>">90 Hari</option>
										<option value="<?php echo $habis4; ?>">120 Hari</option>
										<option value="<?php echo $habis5; ?>">150 Hari</option>
										<option value="<?php echo $habis6; ?>">180 Hari</option>
										<option value="<?php echo $habis7; ?>">210 Hari</option>
										<option value="<?php echo $habis8; ?>">240 Hari</option>
										<option value="<?php echo $habis9; ?>">270 Hari</option>
										<option value="<?php echo $habis10; ?>">300 Hari</option>
										<option value="<?php echo $habis11; ?>">330 Hari</option>
										<option value="<?php echo $habis12; ?>">360 Hari</option>
									</select>
								</div>
                            </div>
							<input type="hidden" class="form-control" name="saldo" value="<?php 
							$qdarimember = "SELECT balance2 FROM member WHERE email = :email";
							$darimember = $databaseConnection->prepare($qdarimember);
							$darimember->bindParam(':email', $menuusername);
							$darimember->execute();
							while($tampilmember=$darimember->fetch(PDO::FETCH_OBJ)){
								echo $tampilmember->balance2;
								}
							 ?>"/>
                            <hr class="dotted">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" id="enter" name="enter" value="enter">
									<i class="fa fa-cart-plus fa-fw"></i> Buat Akun
								</button>
                                <a href="server-reseller.php">
									<button type="button" class="btn btn-danger" id="resetBtn"><i class="fa fa-arrow-circle-left fa-fw"></i> Kembali</button>
								</a>
                            </div>
                            </form>
                        </div>
                    </div>
				</div>
			</div>
			<?php } } ?>
    </section>
    <section class="content">
		<?php include 'base/footer.php'; ?>
	</section>

    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>