<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
error_reporting(0);


$command = "reboot";

$dariserver = $databaseConnection->prepare("SELECT * FROM server WHERE idserver = :idserver");
$dariserver->bindParam(':idserver', $_GET['idserver']);
$dariserver->execute();

while ($tampildariserver = $dariserver->fetch(PDO::FETCH_OBJ)) {
	$host = $tampildariserver->host;
	$passwordvps = $tampildariserver->password;
	
}

    $connection = ssh2_connect($host, 22);
	if (ssh2_auth_password($connection, 'root', $passwordvps)) {
		$stream = ssh2_exec($connection, $command);
		stream_set_blocking($stream, true);
		$data = '';
		while($buffer = fread($stream, 4096)) {
			$data .= $buffer;
		}
		fclose($stream);
		echo $data;
		}
	else {
		 echo "Ada masalah pada Server!";
	}
	
	echo "<script language = 'javascript'>
	alert('Sukses Restart/Reboot Server!');
	window.location = 'manage-server.php';
	</script>
	";
?>