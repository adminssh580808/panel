<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

//ambil host
$qambilhost = "SELECT * FROM akun WHERE id = :id";
$ambilhost = $databaseConnection->prepare($qambilhost);
$ambilhost->bindParam(':id', $_GET['id']);
$ambilhost->execute();

while($exambilhost = $ambilhost->fetch(PDO::FETCH_OBJ)) {
	$host = $exambilhost->host;
	$uservpn = $exambilhost->uservpn;
	
}

$dariserver = $databaseConnection->prepare("SELECT * FROM server WHERE host = :host");
$dariserver->bindParam(':host', $host);
$dariserver->execute();

while ($tampildariserver = $dariserver->fetch(PDO::FETCH_OBJ)) {
	$password = $tampildariserver->password;
	
}

	$command = "service ssh status";
    $connection = ssh2_connect($host, 22);
	if (ssh2_auth_password($connection, 'root', $password)) {
		$stream = ssh2_exec($ssh, $command);
		stream_set_blocking($stream, true);
		$data = '';
		while($buffer = fread($stream, 4096)) {
			$data .= $buffer;
		}
		fclose($stream);
		echo $data;
	} else {
		echo "Ada masalah pada Server!";
	}
?>