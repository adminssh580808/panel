<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');


//ambil host
$qambilhost = "SELECT * FROM akun WHERE id = :id";
$ambilhost = $databaseConnection->prepare($qambilhost);
$ambilhost->bindParam(':id', $_GET['id']);
$ambilhost->execute();

while($exambilhost = $ambilhost->fetch(PDO::FETCH_OBJ)) {
	$host = $exambilhost->host;
	$uservpn = $exambilhost->uservpn;
	
}

$dariserver = $databaseConnection->prepare("SELECT * FROM server WHERE host = :host");
$dariserver->bindParam(':host', $host);
$dariserver->execute();

while ($tampildariserver = $dariserver->fetch(PDO::FETCH_OBJ)) {
	$namavpn = $tampildariserver->password;
	
}

    $connection = ssh2_connect($host, 22);
	if (ssh2_auth_password($connection, 'root', $namavpn)) {
		$result = ssh2_exec($connection, "userdel -r $uservpn");
	} else {
		//nothing
	}
	
	$qhapus = "DELETE FROM akun WHERE id = :id";
	$hapus = $databaseConnection->prepare($qhapus);
	$hapus->bindParam(':id', $_GET['id']);
	$hapus->execute();
	
	echo "<script language = 'javascript'>
	alert('Sukses Menghapus User SSH/VPN!');
	window.location = 'manage-user.php?action=done';
	</script>
	";
?>