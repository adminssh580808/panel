<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['edit'])) {
	
	$status1 = $_POST['status1'];
	$status2 = $_POST['status2'];
	$status3 = $_POST['status3'];
	
	$qserver = "UPDATE server SET status1 = :status1, status2 = :status2, status3 = :status3 WHERE idserver = :idserver";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':status1', $status1);
	$exserver->bindParam(':status2', $status2);
	$exserver->bindParam(':status3', $status3);
	$exserver->bindParam(':idserver', $_POST['idserver']);
	
	if ($status1 == "Silahkan Pilih") {
			$pilih1 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Status Tersedia untuk Member Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
	}
	
	elseif ($status2 == "Silahkan Pilih") {
			$pilih2 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Status Tersedia untuk Reseller Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
	}
	
	elseif ($status3 == "Silahkan Pilih") {
			$pilih3 = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Pembuatan Akun Gagal!</h4>
			<p>Status Tersedia untuk Trial Belum Dipilih</p>
			<hr>
			<p class="mb-0">Silahkan coba kembali.</p>
			</div>
		';
	}
		
	elseif($exserver->execute()) {
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Status Server Berhasil Diedit!</p>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Gagal Mengedit Status Server!</p>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Edit Status Server</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-database fa-fw"></i> Edit Status Server</h3></center></div>
            
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($pilih1)){ echo $pilih1; } ?>
					<?php if(isset($pilih2)){ echo $pilih2; } ?>
					<?php if(isset($pilih3)){ echo $pilih3; } ?>
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-bullseye fa-fw"></i> Edit Status Server</div>
                        <div class="panel-body">                        
                        <?php
                        $qtampil = "SELECT * FROM server WHERE idserver = :idserver LIMIT 0,1";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':idserver', $_REQUEST['idserver']);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
                        ?>
                        	<form  method="post" class="validator-form" action="">
								<div class="form-group">
									<label class="control-label">Name Server</label>
									<input type="text" class="form-control" name="namaserver" value="<?php echo $serv['namaserver']; ?>" readonly />
								</div>
								<div class="form-group">
									<label class="control-label">Host</label>
									<input type="text" class="form-control" name="host" value="<?php echo $serv['host']; ?>" readonly />
								</div>
								<div class="form-group">
									<label class="control-label">Tersedia untuk Member</label>
									<select type="text" class="form-control" name="status1" style="width:100%">
										<option>Silahkan Pilih</option>
										<option>Tersedia</option>
										<option>Tidak</option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label">Tersedia untuk Reseller</label>
									<select type="text" class="form-control" name="status2" style="width:100%">
										<option>Silahkan Pilih</option>
										<option>Tersedia</option>
										<option>Tidak</option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label">Tersedia untuk Trial</label>
									<select type="text" class="form-control" name="status3" style="width:100%">
										<option>Silahkan Pilih</option>
										<option>Tersedia</option>
										<option>Tidak</option>
									</select>
								</div>
								<input type="hidden" name="idserver" value="<?php echo $serv['idserver']; ?>">
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="edit" value="Add">
										<i class="fa fa-save"></i> Simpan
									</button>
									<a href="manage-server.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left"></i> Kembali
										</button>
									</a>
								</div>
                            </form>
							<?php } ?>
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   <?php include '../base/footer.php'; ?>
    
    </section>    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>