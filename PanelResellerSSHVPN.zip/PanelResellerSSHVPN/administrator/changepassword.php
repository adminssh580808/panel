<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['ganti'])) {
	
	$passwordtext = $_POST['password'];
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT, ['cost' => 12,]);
	
	$qubahpass = "UPDATE users SET password = :password WHERE username = :username";
	$ubahpass = $databaseConnection->prepare($qubahpass);
	$ubahpass->bindParam(':password', $password);
	$ubahpass->bindParam(':username', $_SESSION['username']);
		
	if($ubahpass->execute()) {
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Password Berhasil Dirubah!</h4>
			<p>Password Baru : '.$passwordtext.'.</p>
			</div>
		';
	} else {
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Password Gagal Diperbaharui!</p>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Ganti Password</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-key fa-fw"></i> Ganti Password</h3></center></div>
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-key fa-fw"></i> Ganti Password</div>
                        <div class="panel-body">
                        
                        <?php
                        $qtganti = "SELECT * FROM users WHERE username = :username";
                        $tganti = $databaseConnection->prepare($qtganti);
                        $tganti->bindParam(':username', $_SESSION['username']);
                        $tganti->execute();
                        $ganti = $tganti->fetchAll();
                        foreach ($ganti as $gantii) {
                        ?>
							<form  method="post" class="validator-form" action="">
								<div class="col-lg-6">
									<div class="form-group">
										<small>Password Baru</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-key fa-fw"></i></span>
											<input type="password" class="form-control" name="password"/>
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Ulangi Password</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-key fa-fw"></i></span>
											<input type="password" class="form-control" name="confirmPassword" placeholder="******"/>
										</div>
									</div>
								</div>
								<div class="col-lg-12">
									<hr class="dotted">
									<div class="form-group">
										<button type="submit" class="btn btn-primary" name="ganti" value="change">
											<i class="fa fa-save fa-fw"></i> Ganti
										</button>
										<a href="dashboard.php">
											<button type="button" class="btn btn-info" id="resetBtn"><i class="fa fa-arrow-circle-left fa-fw"></i> Kembali</button>
										</a>
									</div>
								</div>
                            </form>
							<?php } ?>
                        </div>
                    </div>
                 </div>                
            </div>
       </div>
        
        <?php include '../base/footer.php'; ?>
    
    </section>
    <!-- Content Block Ends Here (right box)-->
    
    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>