<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
<?php if(isset($_SESSION['username'])) { ?>
<?php } else { header("location: login.php"); } ?>
<div class="page-header"><center><h3>Backup Member</h3></center></div>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-body">
				<table border="1">
					<thead>
						<tr>
							<th>Nama Lengkap</th>
							<th>Username</th>
							<th>Password</th>
							<th>Email</th>
							<th>Jenis Kelamin</th>
							<th>Kab/Kota</th>
							<th>Prov</th>
							<th>No HP</th>
							<th>Saldo Member</th>
							<th>Saldo Reseller</th>
							<th>Akses Trial</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						<?php
						header("Content-type: application/vnd-ms-excel");
						header("Content-Disposition: attachment; filename=Backup-Member.xls");
						$qtserver = "SELECT * FROM member";
						$tserver = $databaseConnection->prepare($qtserver);
						$tserver->execute();
						$server = $tserver->fetchAll();
						foreach ($server as $serv) {
						?>
						<tr class="odd gradeX">
							<td><?php echo $serv['nama']; ?></td>
							<td><?php echo $serv['username']; ?></td>
							<td><?php echo $serv['password']; ?></td>
							<td><?php echo $serv['email']; ?></td>
							<td><?php echo $serv['jk']; ?></td>
							<td><?php echo $serv['kota']; ?></td>
							<td><?php echo $serv['prov']; ?></td>
							<td><?php echo $serv['nohp']; ?></td>
							<td><?php echo number_format($serv['balance1'], 0 , '' , '.' ); ?></td>
							<td><?php echo number_format($serv['balance2'], 0 , '' , '.' ); ?></td>
							<td><?php 
								if($serv['balance3'] = 1) {
									echo "<font color=#0F9D28>Yes</font>";
								} else {
									echo "<font color=red>No</font>";
								}
								?>
							</td>
							<td><?php
								if($serv['status'] == "Pending") {
								 echo "<font color=orange>Pending</font>";
								} elseif($serv['status'] == "Kunci") {
								echo "<font color=red>Locked</font>";
								} else {
								echo "<font color=#0F9D28>Aktif</font>";
								}
								?>
							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="page-header"><center><h6>Backup Date <?php echo $tgl; ?></h6></center></div>
<div class="page-header"><center><h5>Panel Reseller SSH</h5></center></div>
</body>
</html>