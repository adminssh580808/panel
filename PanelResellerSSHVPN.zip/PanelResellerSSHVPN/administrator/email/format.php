<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;font-size:16px'><b>Detail Akun</b></div>
<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
	<tbody>
		<tr style='background:#f2f2f2'>
			<td style='padding:8px 10px;width:100px'>Server</td>
			<th style='padding:8px 2px'>:</th>
			<th style='padding:8px 10px'>".$serv['namaserver']."</th>
		<tr>
		<tr>
			<td style='padding:8px 10px'>Host</td>
			<th style='padding:8px 2px'>:</th>
			<th style='padding:8px 10px'>".$serv['host']."</th>
		</tr>
		<tr style='background:#f2f2f2'>
			<td style='padding:8px 10px;width:100px'>Username</td>
			<th style='padding:8px 2px'>:</th>
			<th style='padding:8px 10px'>".$serv['uservpn']."</th>
		<tr>
		<tr>
			<td style='padding:8px 10px;width:100px'>Expired</td>
			<th style='padding:8px 2px'>:</th>
			<th style='padding:8px 10px'>".$serv['expiredate']."</th>
		</tr>
		<tr style='background:#f2f2f2'>
			<td style='padding:8px 10px'>Creator</td>
			<th style='padding:8px 2px'>:</th>
			<th style='padding:8px 10px'>".$serv['username']."</th>
		<tr>
		<tr>
			<td style='padding:8px 10px'>Harga</td>
			<th style='padding:8px 2px'>:</th>
			<th style='padding:8px 10px'>".$serv['dari']."</th>
		</tr>
	</tbody>
</table>
<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;font-size:16px'>
	Masa Aktif Akun tersebut habis dalam .. Hari Kedepan,<br>
	Silahkan melakukan renew/perpanjang Akun.
	<p>Salah Hormat, <br>Admin.</p>
</div>