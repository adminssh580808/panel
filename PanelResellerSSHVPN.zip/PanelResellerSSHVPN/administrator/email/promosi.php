<?php
date_default_timezone_set('Asia/Jakarta');

include '../../asset/css/config.php';

$qtserver = "SELECT * FROM member";
$tserver = $databaseConnection->prepare($qtserver);
$tserver->execute();
$server = $tserver->fetchAll();
foreach ($server as $serv) {

// SMTP Mailer
require_once('../../function.php');
$to       = $serv['email'];
$subject  = "Promo Tahun Baru 2021";
// Message SMTP Mailer
$message  = "
<table cellpadding='0' cellspacing='0' border='0' width='100%'>
	<tbody>
		<tr>
			<td bgcolor='#f2f2f2' style='font-size:0px'>&nbsp;</td>
			<td bgcolor='#ffffff' width='660' align='center'>
				<table cellpadding='0' cellspacing='0' border='0' width='100%'>
					<tbody>
						<tr>
							<td align='center' width='600' valign='top'>
								<table width='100%' cellpadding='0' cellspacing='0' border='0'>
									<tbody>
										<tr>
											<td bgcolor='#f2f2f2' style='padding-top:10px'></td>
										</tr>
										<tr>
											<td bgcolor='#f2f2f2' style='padding-top:10px'></td>
										</tr>
										<tr>
											<td align='center' valign='top' bgcolor='#ffffff'>
												<table border='0' cellpadding='0' cellspacing='0' style='padding-bottom:10px;padding-top:20px' width='100%'>
													<tbody>
														<tr valign='bottom'>    
															<td width='20' align='center' valign='top'>&nbsp;</td>
															<td>
																<span style='font-size:20px'>
																	<center>
																		<b>PROMO TAHUN BARU</b>
																	</center>
																</span>                                
															</td>
															<td width='20' align='center' valign='top'>&nbsp;</td>
														</tr>
													</tbody>
												</table>
												<table border='0' cellpadding='0' cellspacing='0' style='padding-bottom:10px;padding-top:10px;margin-bottom:10px' width='100%'>
													<tbody>
														<tr valign='bottom'>    
															<td width='20' align='center' valign='top'>&nbsp;</td>
															<td valign='top' style='font-family:Calibri,Trebuchet,Arial,sans serif;font-size:15px;line-height:22px;color:#333333'>
																<p>
																	Yth. <a href='mailto:".$serv['email']."' target='_blank'>".$serv['email']."</a>,<br>
																	Dalam rangka Tahun Baru, Kami Admin ForNesia mempersembahkan promo menarik bagi seluruh member/reseller.
																</p>
																<p>
																	<b>A. DEPOSIT SALDO BONUS 40-50%</b><br>
																	1. Deposit 30.000, saldo yang Anda dapatkan yakni 45.000<br>
																	2. Deposit 50.000, saldo yang Anda dapatkan yakni 75.000<br>
																	3. Deposit 75.000, saldo yang Anda dapatkan yakni 150.000<br>
																	4. Deposit 100.000, saldo yang Anda dapatkan yakni 200.000<br>
																	<br><br>
																	<b>B. CASH BACK 25% SETIAP PEMBELIAN AKUN</b><br>
																	Contoh pembelian Akun dengan harga 10.000, maka saldo Anda Kami kembalikan 2.500,-<br>
																	<br><br>
																	<b>C. PROGRAM REFERAL RESELLER</b><br>
																	Dapatkan 50% saldo dari total deposit reseller yang diajak bergabung oleh Anda.<br>
																	<br><br>
																	<i>Promo ini berlaku sampai 2 Februari 2021</i><br>
																	<br><br>
																	Salam Hormat,<br>Admin
																</p>
															</td>
															<td width='20' align='center' valign='top'>&nbsp;</td>
														</tr>
													</tbody>
												</table>
											</td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
				<table cellpadding='0' cellspacing='0' border='0' width='100%'>
					<tbody>
						<tr>
							<td align='center' width='600' valign='top'>
								<table width='100%' cellpadding='0' cellspacing='0' border='0'>
									<tbody>
										<tr>
											<td bgcolor='#f2f2f2' style='padding-top:20px'></td>
										</tr>
										<tr>
											<td align='center' valign='top' bgcolor='#f2f2f2'>
												<table border='0' cellpadding='0' cellspacing='0' width='100%'>
													<tbody>
														<tr valign='bottom'>   
															<td width='20' align='center' valign='top'>&nbsp;</td>
															<td>
																<table align='left' border='0' cellpadding='0' cellspacing='0'>
																	<tbody>
																		<tr>
																			<td style='font-family:Calibri,Trebuchet,Arial,sans serif;font-size:13px;color:#666;font-weight:bold'>
																				<span>
																					<div style='margin:5px 0;padding:0'>
																						<span style='display:inline'>
																							<span>
																								<a href='https://www.fornesia.com' style='text-decoration:none' target='_blank'>
																									Bantuan&nbsp;
																								</a>
																							</span>
																							<span style='color:#ccc'><span> | </span></span>
																							<span>
																								<a href='https://www.fornesia.com' style='text-decoration:none' target='_blank' >
																									Webiste&nbsp;
																								</a>
																							</span>
																						</span>
																					</div>
																				</span>
																			</td>
																		</tr>
																	</tbody>
																</table>
															</td>
															<td width='20' align='center' valign='top'>&nbsp;</td>    
														</tr>
													</tbody>
												</table>           
												<table border='0' cellpadding='0' cellspacing='0' width='100%'>
													<tbody>
														<tr valign='bottom'>   
															<td width='20' align='center' valign='top'>&nbsp;</td>
															<td>
																<p>
																	Jangan balas ke email ini. Untuk menghubungi Kami, klik 
																	<strong><a href='' style='text-decoration:none' target='_blank' >Bantuan dan Hubungi</a></strong>.
																</p>
															</td>
															<td width='20' align='center' valign='top'>&nbsp;</td>
														</tr>
													</tbody>
												</table>  
												<table border='0' cellpadding='0' cellspacing='0' width='100%'>
													<tbody>
														<tr valign='bottom'>   
															<td width='20' align='center' valign='top'>&nbsp;</td>
															<td>
																<span>  
																	<table border='0' cellpadding='0' cellspacing='0' style='padding-top:10px;font:12px Arial,Verdana,Helvetica,sans-serif;color:#292929' width='100%'>
																		<tbody>
																			<tr>
																				<td>
																					<p>Hak Cipta © 2021 fornesia.com</p>
																				</td>
																			</tr>
																		</tbody>
																	</table>
																</span>
															</td>
															<td width='20' align='center' valign='top'>&nbsp;</td>    
														</tr>
													</tbody>
												</table>
											</td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
			<td bgcolor='#f2f2f2' style='font-size:0px'>&nbsp;</td>
		</tr>
	</tbody>
</table>
";
$from_name = 'no reply';
$from = 'noreply@fornesia.com';
smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, true);
}
?>