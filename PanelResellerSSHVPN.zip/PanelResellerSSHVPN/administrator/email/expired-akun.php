<?php
// SMTP Mailer
require_once('../../function.php');
$to       = 'admin@fornesia.com';
$subject  = "Pringatan Expired Akun";
// Message SMTP Mailer
$message  = "Test Expired";
$from_name = 'no reply';
$from = 'noreply@fornesia.com';
smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, true);
?>