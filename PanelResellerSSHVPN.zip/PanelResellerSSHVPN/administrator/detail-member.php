<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Detail Member</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-user fa-fw"></i> Detail Member</h3></center></div>
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-user fa-fw"></i> Detail Member</div>
                        <div class="panel-body">
							<?php
							$qtampil = "SELECT * FROM member WHERE iduser = :iduser LIMIT 0,1";
							$tampil = $databaseConnection->prepare($qtampil);
							$tampil->bindParam(':iduser', $_REQUEST['iduser']);
							$tampil->execute();
							$server = $tampil->fetchAll();
							foreach ($server as $serv) {
							?>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<small>ID Member</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['iduser']; ?>" disabled />
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Nama Lengkap</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['nama']; ?>" disabled />
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<small>Username</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-at fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['username']; ?>" disabled />
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Email</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-envelope fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['email']; ?>" disabled />
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<small>Kota/Kab</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-building fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['kota']; ?>" disabled />
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Provinsi</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-building-o fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['prov']; ?>" disabled />
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<small>Jenis Kelamin</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-male fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php if($serv['jk'] == "L") { echo "Laki-Laki";} else { echo 'Perempuan';} ?>" disabled />
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>No Handphone</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-phone fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['nohp']; ?>" disabled />
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<small>Saldo Member</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
											<input type="text" class="form-control" name="balance1" value="<?php echo $serv['balance1']; ?>" disabled />
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Saldo Reseller</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
											<input type="text" class="form-control" name="balance2" value="<?php echo $serv['balance2']; ?>" disabled />
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<center><small>Akses Trial</small></center>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-clock-o fa-fw"></i></span>
											<input type="text" class="form-control" name="balance2" value="<?php
											if($serv['balance3'] == '0') {
											 echo "Tidak";
											} else {
											echo "Ya";
											}
											?>" disabled />
										</div>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<small>Status Akun</small>
										<div class="input-group">
											<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-bullseye fa-fw"></i></span>
											<input type="text" class="form-control" value="<?php echo $serv['status']; ?>" disabled />
										</div>
									</div>
								</div>
							</div>
							<hr class="dotted">
							<div class="form-group">
								<a href="manage-member.php">
									<button type="button" class="btn btn-info" id="resetBtn">
										<i class="fa fa-arrow-circle-left"></i> Kembali
									</button>
								</a>
							</div>
                              <?php } ?>            
                        </div>
                    </div>
                 </div>
            </div>
		</div>
        
        <?php include '../base/footer.php'; ?>
    
    </section>
    <!-- Content Block Ends Here (right box)-->
    
    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>