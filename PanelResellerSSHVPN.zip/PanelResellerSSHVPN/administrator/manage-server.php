<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>

<!DOCTYPE html>
<html lang="en">

<head>

<?php include 'base/schema.php'; ?>

<title>Manage Server</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="../asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>	


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-database fa-fw"></i> Manage Server</h3></center></div>
			<div class="row">
				<div class="col-md-offset-3 col-md-3">
					<a href="tambah-server.php">
						<button class="btn btn-success" style="width: 100%"><i class="fa fa-plus fa-fw"></i> Tambah Server</button>
					</a>
					<hr>
				</div>
				<div class="col-md-3">
					<a href="backup-server.php">
						<button class="btn btn-info" style="width: 100%"><i class="fa fa-cloud-download fa-fw"></i> Backup Server</button>
					</a>
					<hr>
				</div>
			</div>
				<?php
				$qtserver = "SELECT * FROM server";
				$tserver = $databaseConnection->prepare($qtserver);
				$tserver->execute();
				$server = $tserver->fetchAll();
				foreach ($server as $serv) {
					$link_config = $serv['link_config'];
				?>			
				<div class="col-sm-6 col-md-4 col-lg-4">
				<div class="row">

					<div class="panel panel-default">
						<div class="panel-heading text-center">
							<?php echo $serv['namaserver'];?> (<?php echo $serv['host']; ?>)
						</div>
						<div class="panel-body" style="padding:0">
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td>Pembelian</td>
										<td><?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM akun WHERE idserver = :idserver AND kode = :kode");
											$kode = "1";
											$horder->bindParam(':idserver', $serv['idserver']);
											$horder->bindParam(':kode', $kode);
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> AKUN
										</td>
									</tr>
									<tr>
										<td>Harga Member</td>
										<td><?php echo number_format($serv['harga1'], 0 , '' , '.' ); ?></td>
									</tr>
									<tr>
										<td>Harga Reseller</td>
										<td><?php echo number_format($serv['harga2'], 0 , '' , '.' ); ?></td>
									</tr>
									<tr>
										<td>Status Member</td>
										<td><?php 
											if ($serv['status1'] == "Tersedia") {
												echo "Tersedia";
											} else {
												echo "Tidak";
											}
											?>
										</td>
									</tr>
									<tr>
										<td>Status Reseller</td>
										<td><?php 
											if ($serv['status2'] == "Tersedia") {
												echo "Tersedia";
											} else {
												echo "Tidak";
											}
											?>
										</td>
									</tr>
									<tr>
										<td>Status Trial</td>
										<td><?php 
											if ($serv['status3'] == "Tersedia") {
												echo "Tersedia";
											} else {
												echo "Tidak";
											}
											?>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-lg-4">
									<div class="form-group">
										<a href="detail-server.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-success" title="Detail Server" style="width:100%">
											<small><i class="fa fa-info fa-fw"></i> Detail</small>
										</button>
									</a>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<a href="edit-server.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-primary" title="Edit Server" style="width:100%">
											<small><i class="fa fa-pencil-square-o fa-fw"></i> Edit</small>
										</button>
									</a>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<a href="manage-user-server.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-info" title="Chek User Server" style="width:100%">
											<small><i class="fa fa-search fa-fw"></i> Chek</small>
										</button>
									</a>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-4">
									<div class="form-group">
										<a href="edit-harga-server.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-warning" title="Edit Harga Server" style="width:100%">
											<small><i class="fa fa-money fa-fw"></i> Harga</small>
										</button>
									</a>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<a href="edit-status-server.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-magneta" title="Edit Status Server" style="width:100%">
											<small><i class="fa fa-bullseye fa-fw"></i> Status</small>
										</button>
									</a>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<a href="edit-server-port.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-success" title="Edit Port Server" style="width:100%">
											<small><i class="fa fa-plug fa-fw"></i> Port</small>
										</button>
									</a>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-4">
									<div class="form-group">
										<a href="backup-userssh-byserver.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-primary" title="Backup User SSH Server" style="width:100%">
											<small><i class="fa fa-user fa-fw"></i> Backup</small>
										</button>
									</a>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<a href="restartserver.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-default" title="Reboot Server" style="width:100%">
											<small><i class="fa fa-power-off fa-fw"></i> Reboot</small>
										</button>
									</a>
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<a href="deleteserver.php?idserver=<?php echo $serv['idserver']; ?>">
										<button class="btn btn-danger" title="Delete Server" style="width:100%">
											<small><i class="fa fa-trash fa-fw"></i> Delete</small>
										</button>
									</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					</div>
                </div>
				<?php } ?>
			</div>
        </div>
		
      <?php include '../base/footer.php'; ?>
    
    </section>
	
	<!-- start: JavaScript-->
	<script type="text/javascript">
	function restartserver(idserver) {
		var answer = confirm('Anda Yakin ?')
		if(answer) {
			window.location = 'restartserver.php?idserver=' +idserver;
			}
		}
	</script>
	
	<script type="text/javascript">
	function deleteserver(idserver) {
		var answer = confirm('Anda Yakin ?')
		if(answer) {
			window.location = 'deleteserver.php?idserver=' +idserver;
			}
		}
	</script>
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="../asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="../asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="../asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>