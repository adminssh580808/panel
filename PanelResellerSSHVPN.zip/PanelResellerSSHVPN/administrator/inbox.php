<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

if(isset($_POST['jawab'])) {
	
	$email = $_POST['email'];
	$pesan = $_POST['pesan'];
	
	$qtampung = "SELECT pesan FROM member WHERE email = :email";
	$tampung = $databaseConnection->prepare($qtampung);
	$tampung->bindParam(':email', $email);
	$tampung->execute();
	// SMTP Mailer
	require_once('../function.php');
	$to       = $email;
	$subject  = "Informasi Pesan Masuk";
	// Message SMTP Mailer
	$message  = "
	<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Pesan Masuk </b></div>
	<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
		<tbody>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px'>Nama Pengirim</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>Admin Panel</th>
			<tr>
			<tr>
				<td style='padding:8px 10px;width:100px'>Isi Pesan</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$pesan."</th>
			</tr>
			<tr style='background:#f2f2f2'>
				<td style='padding:8px 10px'>Tanggal Masuk</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>".$tgl."</th>
			<tr>
			<tr>
				<td style='padding:8px 10px'>Catatan</td>
					<th style='padding:8px 2px'>:</th>
					<th style='padding:8px 10px'>Jangan balas pesan ini.</th>
			</tr>
		</tbody>
	</table>
	";
	$from_name = 'no reply';
	$from = 'noreply@fornesia.com';
	smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
	
	if($email == "Silahkan Pilih") {
		echo "<script language = 'javascript'>
				alert('Pilih Penerima');
				window.location = 'inbox.php';
				</script>
				";
	} else {
	$qsimpan = "UPDATE member SET pesan = :pesan WHERE email = :email";
	$simpan = $databaseConnection->prepare($qsimpan);
	$simpan->bindParam(':pesan', $pesan);
	$simpan->bindParam(':email', $email);
	
	if($simpan->execute()) {
		
		echo "<script language = 'javascript'>
				alert('Pesan Terkirim!');
				window.location = 'inbox.php';
				</script>
				";
		}
		else {
		echo "<script language = 'javascript'>
		alert('Failed Add Funds!');
		window.location = 'inbox.php';
		</script>
		";
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<?php include 'base/schema.php'; ?>

<title>Pesan</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="../asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body>	


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-envelope-o fa-fw"></i> Pesan</h3></center></div>
			<div class="row">
				<div class="col-md-12 col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-envelope-o fa-fw"></i> Daftar Pesan Masuk</div>
						<div class="panel-body">
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
								<thead>
									<tr>
										<th>Nama Pengirim</th>
										<th>Email</th>
										<th>Isi Pesan</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$qtserver = "SELECT * FROM saran";
									$tserver = $databaseConnection->prepare($qtserver);
									$tserver->execute();									
									while ($serv = $tserver->fetch(PDO::FETCH_OBJ)) {
									?>
									<tr class="odd gradeX">
										<td><?php echo $serv->nama_pengirim; ?></td>
										<td><?php echo $serv->email; ?></td>
										<td><?php echo $serv->pesan; ?></td>
										<td>
											<a href="#" onclick="deleteinbox(<?php echo $serv->id;?>)" title="Done" >
											<button class="btn btn-danger">
												<i class="fa fa-trash"></i> Hapus
											</button>
											</a>
										  
										 </td>
									 </tr>
									<?php } ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>

				<div class="col-sm-12">
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-envelope fa-fw"></i> Balas Pesan</div>
                        <div class="panel-body">
                        	<form  method="post" class="validator-form form-horizontal" action="#">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">User</label>
                                    <?php
                                    $qselect = "SELECT username, email FROM member";
                                    $tselect = $databaseConnection->prepare($qselect);
                                    $tselect->execute();
                                    $data = $tselect->fetchAll();
                                    ?>
                                    <div class="col-lg-9">
                                        <select name="email" id="email" class="form-control">
											<option>Silahkan Pilih</option>
											<?php foreach ($data as $row): ?>
											<option value="<?=$row['email']?>"><?=$row['username'] . " - " . $row['email']?></option>
											<?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Isi Pesan</label>
                                    <div class="col-lg-9">
                                        <textarea type="text" class="form-control" name="pesan"></textarea>
										<script id="jsbin-javascript">
										$("textarea").on("keypress",function(e){
										var val = $(this).val();
										var open = val.indexOf('<');
										var close = val.indexOf('>');
										if(open!==-1 && close!==-1) {
										$(this).val(val.replace(val.slice(open,close+1),""));
										}
										});
										</script>
                                    </div>
                                </div>
                            	<div class="form-group">
									<div class="col-sm-offset-3 col-sm-9">
										<button type="submit" class="btn btn-primary" name="jawab">Balas Pesan</button>
									</div>
                            	</div>
                        	</form>
						</div>
                    </div>
				</div>
        </div>
		</div>
	</section>
	
	<section class="content">
		<?php include '../base/footer.php'; ?>
	</section>
    
    <!-- start: JavaScript-->
	<script type="text/javascript">
	function deleteinbox(id) {
		var answer = confirm('Are You Sure ?')
		if(answer) {
			window.location = 'deleteinbox.php?id=' +id;
			}
		}
	</script>
    
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="../asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="../asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="../asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>