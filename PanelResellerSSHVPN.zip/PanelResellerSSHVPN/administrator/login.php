<?php
ob_start();
session_start();
if(isset($_SESSION['username'])) {
	header("location: dashboard.php");
} else {
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['login'])) {
$username = $_POST['username'];
$password = $_POST['password'];

$qlogin = "SELECT * FROM users WHERE username = :username";
$login = $databaseConnection->prepare($qlogin);
$login->bindParam(':username', $username);
$login->execute();
$row = $login->fetchObject();
	
	if($row) {
		if($row->expiredate <= date('Y-m-d')) {
			$pesan = '<div class="alert alert-danger" role="alert">
			<p><b>Panel Sudah Expired!</b><br>Silahkan Hubungi :<br><a href="mailto:fornesiafreak@gmail.com"><i class="fa fa-fw fa-envelope"></i> fornesiafreak@gmail.com</a></p>
			</div>';
		}
		elseif(password_verify($password, $row->password)) {
			$_SESSION['username'] = $row->username;
			//alihkan ke halaman index
			header('location: index.php');
		}
		else {
			$pesan = '<div class="alert alert-danger" role="alert">
			<p><center><b>Password salah</b></center></p>
			</div>';
		}
	}
	else {
		$pesan = '<div class="alert alert-danger" role="alert">
			<p><center><b>Username tidak terdaftar</b></center></p>
			</div>';
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<?php include 'base/schema.php'; ?>

<link rel="stylesheet" href="../asset/css/login-admin.css" media="screen" type="text/css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,700">
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<title>Admin Page</title>
</head>

<body style="background-color:#121215">
	<center>
        <div class="warper container-fluid" style="padding: 0;margin:0;min-height:300px;max-width:400px;">
			<div class="row" style="margin:auto">
            	<div class="col-md-12">
				<div class="page-header" style="margin:25px 0 25px"><center><h1>Admin Login Page</h3></center></div>
				<div class="panel panel-default">
					<div class="panel-heading"><center>Admin Login Page</center></div>
					<div class="panel-body">
						<form action="" method="post">
							<div class="form-group">
								<label class="control-label">Username</label>
								<input class="form-control" type="text" name="username" maxlength="30" placeholder="Username" required/>
							</div>
							<div class="form-group">
								<label class="control-label">Password</label>
								<input class="form-control" type="password" name="password" maxlength="225" placeholder="Password" required/>
							</div>
							<?php if(isset($pesan)){ echo $pesan; } ?>
							<div class="form-group" style="margin-bottom:10px;">
								<input class="btn btn-primary" style="width:100%" type="submit" name="login" value="Sign In"/>
							</div>
						</form>
					</div>
				</div>
					<?php
					$qtsite = "SELECT * FROM site";
					$tsite = $databaseConnection->prepare($qtsite);
					$tsite->execute();
					$site = $tsite->fetchAll();
					foreach ($site as $site)
					$url = $site['url'];
					$name = $site['name'];
					?>
					<p class="text-center">
						Copyright 2017 
						<a href="
						<?php if($url== '') { ?>
							<?php echo "#" ?>
							<?php } else { ?>
							<?php echo $site['url']; }
						?>">
						<b>
						<?php if($name== '') { ?>
							<?php echo "#" ?>
							<?php } else { ?>
							<?php echo $site['name']; }
						?>
						</b></a></p>
				</div> <!-- end login -->
			</div>
		</div>
		<?php } ?>
</body>
</html>