<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['tambah'])) {
	
	$username = $_POST['namauser'];
	$email = $_POST['email'];
	$passwordtext = $_POST['password'];
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT, ['cost' => 12,]);
	
	$qserver = "UPDATE member SET username = :username, password = :password WHERE iduser = :iduser";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':username', $username);
	$exserver->bindParam(':password', $password);
	$exserver->bindParam(':iduser', $_POST['iduser']);
	
	if($exserver->execute()) {
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Password Member Berhasil Dirubah!</h4>
			<p>Username : '.$username.'.</p>
			<p>Email : '.$email.'.</p>
			<p>Password Baru : '.$passwordtext.'.</p>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Password Member Gagal Diedit!</p>
			</div>
		';
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Edit Password Member</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-key fa-fw"></i> Edit Password Member</h3></center></div>
				<div class="row">
					<div class="col-md-offset-3 col-md-6">
						<?php if(isset($berhasil)){ echo $berhasil; } ?>
						<?php if(isset($gagal)){ echo $gagal; } ?>
						<div class="panel panel-default">
							<div class="panel-heading"><i class="fa fa-key fa-fw"></i> Edit Password</div>
							<div class="panel-body">
							<?php
								$qtampil = "SELECT * FROM member WHERE iduser = :iduser LIMIT 0,1";
								$tampil = $databaseConnection->prepare($qtampil);
								$tampil->bindParam(':iduser', $_REQUEST['iduser']);
								$tampil->execute();
								$server = $tampil->fetchAll();
								foreach ($server as $serv) {
							?>
								<form  method="post" class="validator-form" action="">								
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Username</label>
											<input type="text" class="form-control" name="namauser" value="<?php echo $serv['username']; ?>" readonly />
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Email</label>
											<input type="email" class="form-control" name="email" value="<?php echo $serv['email']; ?>" readonly />
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Password</label>
											<input type="password" class="form-control" name="password" placeholder="******"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Re Password</label>
											<input type="password" class="form-control" name="confirmPassword" placeholder="******"/>
										</div>
									</div>
								</div>
								<input type="hidden" name="iduser" value="<?php echo $serv['iduser']; ?>">
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="tambah" value="Add">
										<i class="fa fa-save fa-fw"></i> Simpan
									</button>
									<a href="manage-member.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
										</button>
									</a>
								</div>
								</form>
								<?php } ?>            
							</div>
						</div>
					 </div>
				</div>
		   </div>
        
        <?php include '../base/footer.php'; ?>
    
    </section>
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>