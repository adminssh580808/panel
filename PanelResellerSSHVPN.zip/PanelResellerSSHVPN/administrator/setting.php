<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['simpan'])) {
	
	$name = $_POST['name'];
	$email = $_POST['email'];
	$url = $_POST['url'];
	$fb = $_POST['fb'];
	$telegram = $_POST['telegram'];
	$twitter = $_POST['twitter'];
	$bbm = $_POST['bbm'];
	$wa = $_POST['wa'];
	$line = $_POST['line'];
	
	$qserver = "UPDATE site SET name = :name, email = :email, url = :url, fb = :fb, telegram = :telegram, twitter = :twitter, bbm = :bbm, wa = :wa, line = :line WHERE id = :id";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':name', $name);
	$exserver->bindParam(':email', $email);
	$exserver->bindParam(':url', $url);
	$exserver->bindParam(':fb', $fb);
	$exserver->bindParam(':telegram', $telegram);
	$exserver->bindParam(':twitter', $twitter);
	$exserver->bindParam(':bbm', $bbm);
	$exserver->bindParam(':wa', $wa);
	$exserver->bindParam(':line', $line);
	$exserver->bindParam(':id', $_POST['id']);
	
	if($exserver->execute()) {
		$message = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Data Website Berhasil Dirubah!</h4>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<h4 class="alert-heading">Gagal Merubah Data Website!</h4>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Pengaturan Website</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-wrench fa-fw"></i> Edit Data Website</h3></center></div>
            
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($message)){ echo $message; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-globe fa-fw"></i> Edit Data Webiste</div>
                        <div class="panel-body">                        
                        <?php
                        $qtampil = "SELECT * FROM site WHERE id = :id LIMIT 0,1";
                        $id = "1";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':id', $id);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
                        ?>
                        	<form  method="post" class="validator-form" action="">
								<div class="form-group">
									<label class="control-label">Nama Website/Panel</label>
									<input type="text" class="form-control" name="name" value="<?php echo $serv['name']; ?>"/>
									<small>Masukan Brand / Nama Website.</small>
								</div>
								<div class="form-group">
									<label class="control-label">Alamat Website</label>
									<input type="text" class="form-control" name="url" value="<?php echo $serv['url']; ?>"/>
									<small>Masukan URL / Alamat Website.</small>
								</div>
								<div class="form-group">
									<label class="control-label">Email</label>
									<input type="text" class="form-control" name="email" value="<?php echo $serv['email']; ?>"/>
									<small>Masukan email Anda untuk menerima notifikasi tambah saldo dan pesan yg dikirim member</small>
								</div>
								<div class="form-group">
									<label class="control-label">URL Akun Facebook</label>
									<input type="text" class="form-control" name="fb" value="<?php echo $serv['fb']; ?>"/>
									<small>Masukan alamat Facebook Anda, contoh : https://fb.com/alex</small>
								</div>
								<div class="form-group">
									<label class="control-label">No Whatsapp</label>
									<input type="text" class="form-control" name="wa" value="<?php echo $serv['wa']; ?>" />
									<small>Masukan nomor Whatsapp diawali dengan 62 bukan 0, Contoh : 628787XXXXXXX</small>
								</div>
								<div class="form-group">
									<label class="control-label">URL Akun Telegram</label>
									<input type="text" class="form-control" name="telegram" value="<?php echo $serv['telegram']; ?>"/>
									<small>Masukan alamat akun telegram Anda, contoh : https://t.me/alex</small>
								</div>
								<div class="form-group">
									<label class="control-label">URL Akun Twitter</label>
									<input type="text" class="form-control" name="twitter" value="<?php echo $serv['twitter']; ?>"/>
									<small>Masukan alamat akun twutter Anda, contoh : https://twitter.com/alex</small>
								</div>
								<div class="form-group">
									<label class="control-label">PIN BBM</label>
									<input type="text" class="form-control" name="bbm" value="<?php echo $serv['bbm']; ?>"/>
									<small>Masukan PIN BBM Anda</small>
								</div>
								<div class="form-group">
									<label class="control-label">ID Line</label>
									<input type="text" class="form-control" name="line" value="<?php echo $serv['line']; ?>"/>
									<small>Masukan ID Line Anda</small>
								</div>
								<input type="hidden" name="id" value="<?php echo $serv['id']; ?>">
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="simpan" value="Add">
										<i class="fa fa-save"></i> Simpan
									</button>
									<a href="dashboard.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left"></i> Kembali
										</button>
									</a>
								</div>
                            </form>
							<?php } ?>
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   <?php include '../base/footer.php'; ?>
    
    </section>    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>