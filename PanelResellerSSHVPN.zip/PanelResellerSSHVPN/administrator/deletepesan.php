<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
	
	$qserver = "UPDATE member SET pesan = :pesan WHERE iduser = :iduser";
	$exserver = $databaseConnection->prepare($qserver);
	$pesan = "";
	$exserver->bindParam(':pesan', $pesan);
	$exserver->bindParam(':iduser', $_GET['iduser']);

	if($exserver->execute()) {
		echo "<script language = 'javascript'>
			alert('Berhasil Delete Pesan!');
			window.location = 'manage-member.php?action=success';
			</script>
			";
	} else {
		echo "<script language = 'javascript'>
		alert('Gagal Menghapus Pesan');
		window.location = 'manage-member.php';
		</script>";
	}
?>