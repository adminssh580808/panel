<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');


$qdelete = "DELETE FROM member WHERE iduser = :iduser";
$delete = $databaseConnection->prepare($qdelete);
$delete->bindParam(':iduser', $_GET['iduser']);

if($result = $delete->execute()) {
	echo "<script language = 'javascript'>
		alert('Sukses Delete Member!');
		window.location = 'manage-member.php?action=success';
		</script>
		";
} else {
	echo "<script language = 'javascript'>
	alert('Gagal Menghapus Member');
	window.location = 'manage-member.php';
	</script>";
}
?>
