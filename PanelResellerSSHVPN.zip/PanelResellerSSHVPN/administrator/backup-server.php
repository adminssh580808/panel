<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
<?php if(isset($_SESSION['username'])) { ?>
<?php } else { header("location: login.php"); } ?>
<div class="page-header"><center><h3>Backup Server</h3></center></div>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-body">
				<table border="1">
					<thead>
						<tr>
							<th>Server</th>
							<th>Host</th>
							<th>Password</th>
							<th>Lokasi</th>
							<th>ISP</th>
							<th>Username Trial</th>
							<th>Harga Member</th>
							<th>Harga Reseller</th>
							<th>Port OpenSSH</th>
							<th>Port Dropbear</th>
							<th>Port Squid</th>
							<th>Port OVPN</th>
							<th>Link Config</th>
							<th>Status Member</th>
							<th>Status Reseller</th>
							<th>Status Trial</th>
							<th>Catatan</th>
						</tr>
					</thead>
					<tbody>
						<?php
						header("Content-type: application/vnd-ms-excel");
						header("Content-Disposition: attachment; filename=Backup-Server.xls");
						$qtserver = "SELECT * FROM server";
						$tserver = $databaseConnection->prepare($qtserver);
						$tserver->execute();
						$server = $tserver->fetchAll();
						foreach ($server as $serv) {
						?>
						<tr class="odd gradeX">
							<td><?php echo $serv['namaserver']; ?></td>
							<td><?php echo $serv['host']; ?></td>
							<td><?php echo $serv['password']; ?></td>
							<td><?php echo $serv['lokasi']; ?></td>
							<td><?php echo $serv['isp']; ?></td>
							<td><?php echo $serv['trial']; ?></td>
							<td><?php echo $serv['harga1']; ?></td>
							<td><?php echo $serv['harga2']; ?></td>
							<td><?php echo $serv['openssh']; ?></td>
							<td><?php echo $serv['dropbear']; ?></td>
							<td><?php echo $serv['squid']; ?></td>
							<td><?php echo $serv['ovpn']; ?></td>
							<td><?php echo $serv['link_config']; ?></td>
							<td><?php echo $serv['status1']; ?></td>
							<td><?php echo $serv['status2']; ?></td>
							<td><?php echo $serv['status3']; ?></td>
							<td><?php echo $serv['catatan']; ?></td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="page-header"><center><h6>Backup Date <?php echo $tgl; ?></h6></center></div>
<div class="page-header"><center><h5>Panel Reseller SSH</h5></center></div>
</body>
</html>