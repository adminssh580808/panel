<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$waktu1 = date('Y-m-d h:i:s');

if(isset($_POST['tambah'])) {
	
	$username = $_POST['namauser'];
	$nama = $_POST['nama'];
	$password = password_hash($_POST['password'], PASSWORD_DEFAULT, ['cost' => 12,]);
	$password2 = $_POST['password'];
	$email = $_POST['email'];
	$jk = $_POST['jk'];
	$kota = $_POST['kota'];
	$prov = $_POST['prov'];
	$nohp = $_POST['nohp'];
	$balance1 = $_POST['balance1'];
	$balance2 = $_POST['balance2'];
	$balance3 = $_POST['balance3'];
	$status = $_POST['status'];
	$waktu = $waktu1;
	
	$qcek = "SELECT * FROM member WHERE username = :username";
	$cek = $databaseConnection->prepare($qcek);
	$cek->bindParam(':username', $username);
	$cek->execute();
	
	if($cek->rowCount() > 0) {
	$pesanerror = '
	<div class="alert alert-danger" role="alert">
	<center><b>Username sudah digunakan, silahkan ganti dengan yang lain.</b></center>
	</div>';
	}
	elseif($email != ''){
	$qcek2 = "SELECT * FROM member WHERE email = :email";
	$cek2 = $databaseConnection->prepare($qcek2);
	$cek2->bindParam(':email', $email);
	$cek2->execute();
		if($cek2->rowCount() > 0) {
		$pesanerror = '
		<div class="alert alert-danger" role="alert">
		<center><b>Email sudah digunakan, silahkan ganti dengan yang lain.</b></center>
		</div>';
		}
		elseif($nohp != ''){
		$qcek3 = "SELECT * FROM member WHERE nohp = :nohp";
		$cek3 = $databaseConnection->prepare($qcek3);
		$cek3->bindParam(':nohp', $nohp);
		$cek3->execute();
			if($cek3->rowCount() > 0) {
			$pesanerror = '
			<div class="alert alert-danger" role="alert">
			<center><b>Nomor HP sudah digunakan, silahkan ganti dengan yang lain.</b></center>
			</div>';
			}
			elseif($username != '' && $email != '' && $nohp != ''){
			$hitung = $databaseConnection->prepare("SELECT COUNT(*) FROM member");
			$hitung->execute();
			$num_rows = $hitung->fetchColumn();
				if($num_rows == 1000) {
				$pesanerror = '
				<div class="alert alert-danger" role="alert">
				<center><b>Kuota Member mencapai maksimum (' .$num_rows. '). <br>Silahkan Upgrade Paket Panel Anda.</b></center>
				</div>';
				}
				else {
				// SMTP Mailer
				require_once('../function.php');
				$to       = $email;
				$subject  = "Informasi Akun";
				// Message SMTP Mailer
				$message  = "
				<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;margin-to:15px;border-top:1px solid #eee;font-size:16px'><b>Detail Registrasi</b></div>
				<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
					<tbody>
						<tr style='background:#f2f2f2'>
							<td style='padding:8px 10px;width:100px'>Nama</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$nama."</th>
						<tr>
						<tr>
							<td style='padding:8px 10px'>Username</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$username."</th>
						</tr>
						<tr style='background:#f2f2f2'>
							<td style='padding:8px 10px;width:100px'>Email</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$email."</th>
						<tr>
						<tr>
							<td style='padding:8px 10px'>Password</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$password2."</th>
						</tr>
						<tr style='background:#f2f2f2'>
							<td style='padding:8px 10px'>No HP</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$nohp."</th>
						</tr>
						</tr>
							<td style='padding:8px 10px'>J K</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$jk."</th>
						</tr>
						<tr style='background:#f2f2f2'>
							<td style='padding:8px 10px'>Kab/Kota</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$kota."</th>
						</tr>
						<tr>
							<td style='padding:8px 10px'>Provinsi</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$prov."</th>
						</tr>
						<tr style='background:#f2f2f2'>
							<td style='padding:8px 10px'>Saldo Member</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$balance1."</th>
						</tr>
						<tr>
							<td style='padding:8px 10px'>Saldo Reseller</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$balance2."</th>
						</tr>
						<tr style='background:#f2f2f2'>
							<td style='padding:8px 10px'>Tgl Daftar</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$waktu."</th>
						</tr>
						<tr>
							<td style='padding:8px 10px'>Status Akun</td>
								<th style='padding:8px 2px'>:</th>
								<th style='padding:8px 10px'>".$status."</th>
						</tr>
					</tbody>
				</table>
				<div style='padding:10px;margin-bottom:15px;border-bottom:1px solid #eee;font-size:16px'>
					Kontak Admin :<br>
					Whatsapp : 08563776008<br>
					Facebook : https://fb.me/fornesiacom<br>
					Telegram : @suryadewa87<br>
				</div>
				<table cellpadding='0' cellspacing='0' border='0' style='border-bottom:1px solid #eee;text-align:left;background:#f9f9f9;margin:20px 0;width:100%'>
					<tbody>
						<tr style='background:black'>
							<td style='text-align:center;padding:8px 0;width:100px;color:white'>
							<a href='https://www.fornesia.com' style='color:#fff;text-decoration:none;'><b>ForNesia Forum</b></a>
							</td>
						</tr>
					</tbody>
				</table>"
				;
				$from_name = 'no reply';
				$from = 'noreply@fornesia.com';
				smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
				$quser = "INSERT INTO member SET nama = :nama, username = :username, password = :password, email = :email, jk = :jk, kota = :kota, prov = :prov, nohp = :nohp, balance1 = :balance1, balance2 = :balance2, balance3 = :balance3, status = :status, waktu = :waktu";
				$exuser = $databaseConnection->prepare($quser);
				$exuser->bindParam(':nama', $nama);
				$exuser->bindParam(':username', $username);
				$exuser->bindParam(':password', $password);
				$exuser->bindParam(':email', $email);
				$exuser->bindParam(':jk', $jk);
				$exuser->bindParam(':kota', $kota);
				$exuser->bindParam(':prov', $prov);
				$exuser->bindParam(':nohp', $nohp);
				$exuser->bindParam(':balance1', $balance1);
				$exuser->bindParam(':balance2', $balance2);
				$exuser->bindParam(':balance3', $balance3);
				$exuser->bindParam(':status', $status);
				$exuser->bindParam(':waktu', $waktu);
				$exuser->execute();
				
				$berhasil = '
					<div class="alert alert-success" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="alert-heading">Detail Member Baru!</h4>
					<p>Nama Lengkap : '.$nama.'</p>
					<p>Username : '.$username.'</p>
					<p>Emal : '.$email.'</p>
					<p>Password : '.$password2.'</p>
					<p>Jenis Kelamin : '.$jk.'</p>
					<p>Kab/Kota : '.$kota.'</p>
					<p>Provinsi : '.$prov.'</p>
					<p>No HP : '.$nohp.'</p>
					<p>Saldo Member : '.$balance1.'</p>
					<p>Saldo Reseller : '.$balance2.'</p>
					<p>Status : '.$status.'</p>
					<hr>
					<p class="mb-0">Selalu Patuhi Peraturan Server Kami</p>
					<p>Dibuat : '.$waktu.'</p>
					</div>
				';
				}
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<title>Tambah Member</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />

<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-user-plus fa-fw"></i> Tambah Member</h3></center></div>
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-user fa-fw"></i> Detail Member</div>
                        <div class="panel-body">
							<span class="text-danger"><?php if (isset($pesanerror)) { echo $pesanerror; } ?></span>
                        	<form  method="post" class="validator-form" action="">
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<small>Nama Lengkap</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-user fa-fw"></i></span>
												<input type="text" class="form-control" name="nama" placeholder="Ex: BabangTamvan" required />
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<small>Usename</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-at fa-fw"></i></span>
												<input type="text" class="form-control" name="namauser" placeholder="Ex: BabangTamvan" required />
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<small>Password</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-lock fa-fw"></i></span>
												<input type="password" class="form-control" name="password" placeholder="******"/>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<small>Ulangi Password</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-lock fa-fw"></i></span>
												<input type="password" class="form-control" name="confirmPassword" placeholder="******"/>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<small>Email</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-envelope fa-fw"></i></span>
												<input type="text" class="form-control" name="email" required />
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<small>Kota/Kab</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-building fa-fw"></i></span>
												<input type="text" class="form-control" name="kota" required />
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<small>Provinsi</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-building-o fa-fw"></i></span>
												<input type="text" class="form-control" name="prov" required />
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<small>Jenis Kealamin</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-male fa-fw"></i></span>
												<select type="text" class="form-control" name="jk" style="width:100%">
													<option>Laki-Laki</option>
													<option>Perempuan</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<small>No Handphone/Whatsapp</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-phone fa-fw"></i></span>
												<input type="text" class="form-control" name="nohp" required />
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<small>Saldo Member</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
												<input type="number" class="form-control" name="balance1" value="0" required />
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<small>Saldo Reseller</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-money fa-fw"></i></span>
												<input type="number" class="form-control" name="balance2" value="0" required/>
											</div>
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<small>Membuat Trial Akun</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-clock-o fa-fw"></i></span>
												<select type="text" class="form-control" name="balance3" style="width:100%">
													<option value="0">Tidak</option>
													<option value="1">Ya</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<small>Status</small>
											<div class="input-group">
												<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-bullseye fa-fw"></i></span>
												<select type="text" class="form-control" name="status" style="width:100%">
													<option>Aktif</option>
													<option>Pending</option>
													<option>Kunci</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="tambah" value="Add">
										<i class="fa fa-user-plus fa-fw"></i> Tambah Member
									</button>
									<button type="button" class="btn btn-danger" id="resetBtn">
										<i class="fa fa-trash fa-fw"></i> Reset
									</button>
									<a href="manage-member.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left"></i> Kembali
										</button>
									</a>
								</div>
                            </form>
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   
	   <?php include '../base/footer.php'; ?>
    
    </section>
	
	<script id="jsbin-javascript">
	$("textarea").on("keypress",function(e){
	var val = $(this).val();
	var open = val.indexOf('<');
	var close = val.indexOf('>');
	if(open!==-1 && close!==-1) {
	$(this).val(val.replace(val.slice(open,close+1),""));
	}
	});
	</script>
	
	<script id="jsbin-javascript">
	$("input").on("keypress",function(e){
	var val = $(this).val();
	var open = val.indexOf('<');
	var close = val.indexOf('>');
	if(open!==-1 && close!==-1) {
	$(this).val(val.replace(val.slice(open,close+1),""));
	}
	});
	</script>

    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>