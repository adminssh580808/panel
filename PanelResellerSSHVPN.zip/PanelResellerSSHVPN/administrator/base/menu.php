<?php
//Membuat batasan waktu sesion untuk user di PHP 
$timeout = 10; // Set timeout menit
$logout_redirect_url = "logout.php"; // Set logout URL
 
$timeout = $timeout * 60; // Ubah menit ke detik
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        session_destroy();
        header('location: logout.php');
    }
}
$_SESSION['start_time'] = time();

if(isset($_SESSION['username'])) {
?>
<aside class="left-panel">
    <div class="user text-center">
		<img src="../images/brand.ico" class="img-circle" alt="Nama Website">
		<h4 class="user-name"><font color="#7a7e8a"><?php echo ucwords(strtolower($_SESSION['username'])); ?></font></h4>
		<div class="dropdown user-login">
			<button class="btn btn-xs dropdown-toggle btn-rounded" type="button" data-toggle="dropdown" aria-expanded="true">
				<i class="fa fa-circle status-icon available"></i> Online <i class="fa fa-angle-down"></i>
			</button>
			<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownmenu">
				<li role="presentation"><a role="menuitem" href="logout.php"><i class="fa fa-circle status-icon signout"></i> Sign out</a></li>
			</ul>
		</div>
	</div>	
	<nav class="navigation">
		<ul class="list-unstyled">
			<li><a href="dashboard.php"><i class="fa fa-home fa-fw"></i> <span class="nav-label">Dashboard</span></a></li>
			<li><a href="manage-member.php"><i class="fa fa-user fa-fw"></i> <span class="nav-label">Manage Member</span></a></li>
			<li><a href="manage-server.php"><i class="fa fa fa-database fa-fw"></i> <span class="nav-label">Manage Server</span></a></li>
			<li><a href="manage-user.php"><i class="fa fa fa-terminal fa-fw"></i> <span class="nav-label">Manage User SSH</span></a></li>
			<li>
				<a href="manage-payment.php">
				<i class="fa fa fa-money fa-fw"></i> <span class="nav-label">Manage Payment</span>
					<?php
						$huser = $databaseConnection->prepare("SELECT COUNT(*) FROM payment WHERE lunas = :lunas");
						$lunas = "Tidak";
						$huser->bindParam(':lunas', $lunas);
						$huser->execute();
						$usernum_rows = $huser->fetchColumn();
						if($usernum_rows == 0) {
						echo "";
						} 
						else {
						echo "<span class='badge'>" .$usernum_rows. "</span>";
						}
					?>			
				</a>
			</li>
			<li><a href="manage-config.php"><i class="fa fa fa-download fa-fw"></i> <span class="nav-label">Manage Config</span></a></li>
			<li class="has-submenu"><a href="#"><i class="fa fa-wrench fa-fw"></i> <span class="nav-label">Setting</span></a>
				<ul class="list-unstyled">
					<li><a href="informasi.php"><i class="fa fa-bullhorn fa-fw"></i>Informasi</a></li>
					<li><a href="setting.php"><i class="fa fa-globe fa-fw"></i>Edit Data Website</a></li>
					<li><a href="changepassword.php"><i class="fa fa-key fa-fw"></i>Ganti Password</a></li>
				</ul>
			</li>
			<li><a href="history.php"><i class="fa fa-history fa-fw"></i><span class="nav-label"> History</span></a></li>
			<li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i><span class="nav-label"> Log Out</span></a></li>
		</ul>
	</nav>
		
</aside>
<?php 
} else {
	header("location: login.php");
}
?>