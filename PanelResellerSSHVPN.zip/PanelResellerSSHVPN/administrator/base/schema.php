<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Panel Admin">
<meta name="keywords" content="SSH VPN Panel">
<meta name="author" content="fornesia">
<link rel="icon" href="../images/brand.png" sizes="32x32">