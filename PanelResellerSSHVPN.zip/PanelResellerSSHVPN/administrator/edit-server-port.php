<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

if(isset($_POST['edit'])) {
	
	$openssh = $_POST['openssh'];
	$dropbear = $_POST['dropbear'];
	$squid = $_POST['squid'];
	$ovpn = $_POST['ovpn'];
	
	$qserver = "UPDATE server SET openssh = :openssh, dropbear = :dropbear, squid = :squid, ovpn = :ovpn WHERE idserver = :idserver";
	$exserver = $databaseConnection->prepare($qserver);
	$exserver->bindParam(':openssh', $openssh);
	$exserver->bindParam(':dropbear', $dropbear);
	$exserver->bindParam(':squid', $squid);
	$exserver->bindParam(':ovpn', $ovpn);
	$exserver->bindParam(':idserver', $_POST['idserver']);
	
	
	if($exserver->execute()) {
		$berhasil = '
			<div class="alert alert-success" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Port Server Berhasil Diedit!</p>
			</div>
		';
	} else {
		$gagal = '
			<div class="alert alert-danger" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<p>Gagal Mengedit Server!</p>
			</div>
		';
	}
}		
?>
<!DOCTYPE html>
<html lang="en">

<head>
  
<?php include 'base/schema.php'; ?>

<title>Edit Port Server</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="../asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="../asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
        	
            <div class="page-header"><center><h3><i class="fa fa-database fa-fw"></i> Edit Port Server</h3><center></div>
            
            <div class="row">
            	<div class="col-md-offset-3 col-md-6">
					<?php if(isset($pilih1)){ echo $pilih1; } ?>
					<?php if(isset($pilih2)){ echo $pilih2; } ?>
					<?php if(isset($pilih3)){ echo $pilih3; } ?>
					<?php if(isset($berhasil)){ echo $berhasil; } ?>
					<?php if(isset($gagal)){ echo $gagal; } ?>
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-plug fa-fw"></i> Edit Port Server</div>
                        <div class="panel-body">                        
                        <?php
                        $qtampil = "SELECT * FROM server WHERE idserver = :idserver LIMIT 0,1";
                        $tampil = $databaseConnection->prepare($qtampil);
                        $tampil->bindParam(':idserver', $_REQUEST['idserver']);
                        $tampil->execute();
                        $server = $tampil->fetchAll();
                        foreach ($server as $serv) {
                        ?>
                        	<form  method="post" class="validator-form" action="">
								<div class="row">
									<input type="hidden" class="form-control" name="idserver" value="<?php echo $serv['idserver']; ?>"/>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port OpenSSH</label>
											<input type="text" class="form-control" name="openssh" value="<?php echo $serv['openssh']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port Dropbear</label>
											<input type="text" class="form-control" name="dropbear" value="<?php echo $serv['dropbear']; ?>"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port Squid</label>
											<input type="text" class="form-control" name="squid" value="<?php echo $serv['squid']; ?>"/>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label">Port VPN</label>
											<input type="text" class="form-control" name="ovpn" value="<?php echo $serv['ovpn']; ?>"/>
										</div>
									</div>
								</div>
								<hr class="dotted">
								<div class="form-group">
									<button type="submit" class="btn btn-primary" name="edit" value="Add">
										<i class="fa fa-save fa-fw"></i> Simpan
									</button>
									<a href="manage-server.php">
										<button type="button" class="btn btn-info" id="resetBtn">
											<i class="fa fa-arrow-circle-left fa-fw"></i> Kembali
										</button>
									</a>
								</div>
                            </form>
							<?php } ?>
                        </div>
                    </div>
                 </div>
            </div>
       </div>
	   <?php include '../base/footer.php'; ?>
    
    </section>    
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="../asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="../asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="../asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="../asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="../asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>