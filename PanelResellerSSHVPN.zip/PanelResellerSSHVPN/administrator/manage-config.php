<?php
ob_start();
session_start();
include '../asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
$tgl = date('Y-m-d');

if(isset($_POST['enter'])) {
	$nama_config = $_POST['nama_config'];
	$file = addslashes($_FILES['config']['name']);
	$qsimpan = "INSERT INTO config SET nama_config = :nama_config, tgl = :tgl, config = :config";
	$hsimpan = $databaseConnection->prepare($qsimpan);
	$hsimpan->bindParam(':nama_config', $nama_config);
	$hsimpan->bindParam(':config', $config);
	$hsimpan->bindParam(':tgl', $tgl);
	$hsimpan->bindParam(':config', $file);
	$hsimpan->execute();
	
	$fileName = $_FILES['config']['name'];
	// Simpan di Folder config
	move_uploaded_file($_FILES['config']['tmp_name'], "../config/".$_FILES['config']['name']);
	echo "<script language = 'javascript'>
	window.location = 'manage-config.php';
	</script>
	";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<?php include 'base/schema.php'; ?>

<title>Config</title>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="../asset/css/bootstrap/bootstrap.css" /> 

<!-- datatables Styling  -->
<link rel="stylesheet" href="../asset/css/plugins/datatables/jquery.dataTables.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Fonts  -->


<!-- Base Styling  -->
<link rel="stylesheet" href="../asset/css/app/theme.css" />
</head>

<body>	


	
	<?php include 'base/menu.php'; ?>
	
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        <div class="warper container-fluid">
			<div class="page-header"><center><h3><i class="fa fa-download fa-fw"></i> Manage Config</h3></center></div>
			<div class="row">
				<div class="col-md-offset-3 col-md-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-upload fa-fw"></i> Upload Config</div>
                        <div class="panel-body">
                        	<form  method="post" class="validator-form" action="" enctype="multipart/form-data">
								<div class="form-group">
									<label class="control-label">Nama Config</label>
									<input type="text" class="form-control" name="nama_config" required />
								</div>
								<input type="hidden" class="form-control" name="tgl" value="<?php echo $tgl;?>" disabled />
								 <div class="form-group">
									<label class="control-label">File</label>
									<input type="file" name="config" required />
								</div>
								<div class="form-group">
									<button type="submit" class="btn btn-primary" id="enter" name="enter" value="enter">
										<i class="fa fa-upload fa-fw"></i> Upload
									</button>
									<button type="reset" class="btn btn-warning" id="resetBtn">
										<i class="fa fa-trash fa-fw"></i> Reset
									</button>
								</div>
                            </form>
                        </div>
                    </div>
				</div>
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-trash-o fa-fw"></i> Hapus Config</div>
						<div class="panel-body" style="min-height:13.05pc">
							<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="basic-datatable">
								<thead>
									<tr>
										<th><center>Tanggal</center></th>
										<th><center>Nama Config</center></th>
										<th><center>Hapus</center></th>
									</tr>
								</thead>
								<tbody>
									<?php
									$qtserver = "SELECT * FROM config";
									$tserver = $databaseConnection->prepare($qtserver);
									$tserver->execute();
									$server = $tserver->fetchAll();
									foreach ($server as $serv) {
									?>
									<tr class="odd gradeX">
										<td><?php echo $serv['tgl']; ?></td>
										<td><?php echo $serv['nama_config']; ?></td>
										<td>
											<center>
												<a class="btn btn-danger" href="#" onclick="deleteconfig(<?php echo $serv['id'];?>)">
													<i class="fa fa-trash fa-fw"></i> Hapus
												</a>
											</center>
										</td>
									 </tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
        </div>
      
	  <?php include '../base/footer.php'; ?>
    
    </section>
	
    <!-- start: JavaScript-->
	<script type="text/javascript">
	function deleteconfig(id) {
		var answer = confirm('Anda Yakin ?')
		if(answer) {
			window.location = 'deleteconfig.php?id=' +id;
			}
		}
	</script>
    
    <!-- JQuery v1.9.1 -->
	<script src="../asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    
    <!-- Bootstrap -->
    <script src="../asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="../asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    
	<!-- Data Table -->
    <script src="../asset/js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="../asset/js/plugins/datatables/DT_bootstrap.js"></script>
    <script src="../asset/js/plugins/datatables/jquery.dataTables-conf.js"></script>
    
    
    <!-- Custom JQuery -->
	<script src="../asset/js/app/custom.js" type="text/javascript"></script>
   
</body>
</html>
