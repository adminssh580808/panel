<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
    
<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" /> 

<!-- Title  -->
<title>Dashboard Reseller SSH VPN Premium</title>
</head>

<body>

	<?php include 'base/menu.php'; ?>
    
    <section class="content">
    	
        <?php include 'base/header.php'; ?>
        
        
        <div class="warper container-fluid">
            <div class="page-header"><center><h3><i class="fa fa-fw fa-home"></i> Beranda</h3></center></div>
			<div class="row">
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Jumlah Server</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-database fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
										$hitung = $databaseConnection->prepare("SELECT COUNT(*) FROM server");
										$hitung->execute();
										$num_rows = $hitung->fetchColumn();
										echo $num_rows;
										?> Server" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Server Member</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-server fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horde = $databaseConnection->prepare("SELECT COUNT(*) FROM server WHERE status1 = :status1");
											$status1 = 'Tersedia';
											$horde->bindParam(':status1', $status1);
											$horde->execute();
											$servnum_rows = $horde->fetchColumn();
											echo $servnum_rows;
											?> Server Tersedia" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Server Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-server fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horde = $databaseConnection->prepare("SELECT COUNT(*) FROM server WHERE status2 = :status2");
											$status2 = 'Tersedia';
											$horde->bindParam(':status2', $status2);
											$horde->execute();
											$servnum_rows = $horde->fetchColumn();
											echo $servnum_rows;
											?> Server Tersedia" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Server Trial</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-server fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horde = $databaseConnection->prepare("SELECT COUNT(*) FROM server WHERE status3 = :status3");
											$status3 = 'Tersedia';
											$horde->bindParam(':status3', $status3);
											$horde->execute();
											$servnum_rows = $horde->fetchColumn();
											echo $servnum_rows;
											?> Server Tersedia" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Saldo Member</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo number_format($deposit['balance1'], 0 , '' , '.' ); ?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Saldo Reseller</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-money fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php echo number_format($deposit['balance2'], 0 , '' , '.' ); ?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Jumlah Pembelian</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM akun WHERE username = :pengguna");
											$horder->bindParam(':pengguna', $menuusername);
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Akun" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Akses Trial</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-clock-o fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											if($balance3 == '0') {
											 echo "Tidak";
											} else {
											echo "Ya";
											}
											?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Pesan Masuk</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											if($pesan == '') {
											 echo "Kosong";
											} else {
											echo "1 Pesan";
											}
											?>" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Pesan Terkirim</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM saran WHERE email = :pengguna");
											$horder->bindParam(':pengguna', $menuusername);
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Pesan" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Permintaan Deposit</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-exchange fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
									$pay = $databaseConnection->prepare("SELECT COUNT(*) FROM payment WHERE email = :pengguna");
									$pay->bindParam(':pengguna', $menuusername);
									$pay->execute();
									$pays = $pay->fetchColumn();
									echo $pays;
									?> Permintaan" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-heading"><center>Config Tersedia</center></div>
						<div class="panel-body">
							<div class="form-group">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-download fa-fw"></i></span>
									<input type="text" class="form-control" value="<?php
											$horder = $databaseConnection->prepare("SELECT COUNT(*) FROM config");
											$horder->execute();
											$ordernum_rows = $horder->fetchColumn();
											echo $ordernum_rows;
											?> Config" disabled />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Lain-lain -->
			<div class="row">
				<?php
					$qtinformasi = "SELECT * FROM informasi";
					$tinformasi = $databaseConnection->prepare($qtinformasi);
					$tinformasi->execute();
					$informasi = $tinformasi->fetchAll();
					foreach ($informasi as $info)
						
				?>
				<div class="col-lg-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><center>Pengumuman</center></div>
                        <div class="panel-body" style="min-height:18.3pc">
							<textarea style="resize: none;width:100%;min-height:268px;border:none;background:transparent;" disabled ><?php
							if($info['pengumuman'] == '') {
							 echo '';
							} else {
							echo $info['pengumuman'];
							}
							?></textarea>
                        </div>
                    </div>
                </div>
				<div class="col-lg-6">
                	<div class="panel panel-default">
                        <div class="panel-heading"><center>Peraturan Server</center></div>
                        <div class="panel-body" style="min-height:18.3pc">
							<textarea style="resize: none;width:100%;min-height:268px;border:none;background:transparent;" disabled ><?php
							if($info['peraturan'] == '') {
							 echo '';
							} else {
							echo $info['peraturan'];
							}
							?></textarea>
                        </div>
                    </div>
                </div>
			</div>

		</div>
		
		<!-- Footer -->
        <?php include 'base/footer.php'; ?>
        
    
    </section>

    <!-- JQuery v1.9.1 -->
	<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- Chart JS -->
    <script src="asset/js/plugins/DevExpressChartJS/dx.chartjs.js"></script>
    <script src="asset/js/plugins/DevExpressChartJS/world.js"></script>
   	<!-- For Demo Charts -->
    <script src="asset/js/plugins/DevExpressChartJS/demo-charts.js"></script>
    <script src="asset/js/plugins/DevExpressChartJS/demo-vectorMap.js"></script>
    
    <!-- Sparkline JS -->
    <script src="asset/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!-- For Demo Sparkline -->
    <script src="asset/js/plugins/sparkline/jquery.sparkline.demo.js"></script>
    
    <!-- Angular JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.0-beta.14/angular.min.js"></script>
	
    <!-- ToDo List Plugin -->
    <script src="asset/js/angular/todo.js"></script>    
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
 
</body>

</html>