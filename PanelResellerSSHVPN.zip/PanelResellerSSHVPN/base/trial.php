<?php
function passFunc1($len1, $set1 = "") {
$gen1 = "";

for($i=0;$i<$len1;$i++) {
$set1 = str_shuffle($set1);
$gen1 .= $set1[0];
}

return $gen1;
}
 $passcode1=passFunc1(4,'abcdefghijklmnopqrstuvwxyzABCDEFGHIZKLMNOPQRSTUVWXYZ123456789');
 echo "trial-".$passcode1;
?>