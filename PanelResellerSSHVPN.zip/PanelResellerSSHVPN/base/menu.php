<?php
//Membuat batasan waktu sesion untuk user di PHP 
$timeout = 10; // Set timeout menit
$logout_redirect_url = "logout.php"; // Set logout URL
 
$timeout = $timeout * 60; // Ubah menit ke detik
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        session_destroy();
        header('location: logout.php');
    }
}
$_SESSION['start_time'] = time();

if(isset($_SESSION['email'])) {
	$menuusername = $_SESSION['email'];	
	$qbalance1 = "SELECT * FROM member WHERE email = :email LIMIT 0,1";
	$balance1 = $databaseConnection->prepare($qbalance1);
	$balance1->bindParam(':email', $menuusername);
	$balance1->execute();
	$saldo = $balance1->fetchAll();
	foreach ($saldo as $deposit) {
	$iduser = $deposit['iduser'];
	$saldo = $deposit['balance1'];
	$namaku = $deposit['username'];
	$pesan = $deposit['pesan'];
	$jk = $deposit['jk'];
	$balance2 = $deposit['balance2'];
	$balance3 = $deposit['balance3'];
?>
<aside class="left-panel">    		
	<div class="user text-center">
		<img src="<?php if($jk == "P") { echo "images/logo2.png"; } else { echo "images/logo1.png"; } ?>" class="img-circle" alt="Nama Website">
		<h4 class="user-name"><font color="#7a7e8a"><?php echo ucwords(strtolower($namaku)); ?></font></h4>
		<div class="dropdown user-login">
			<button class="btn btn-xs dropdown-toggle btn-rounded" type="button" data-toggle="dropdown" aria-expanded="true">
				<i class="fa fa-circle status-icon available"></i> Online <i class="fa fa-angle-down"></i>
			</button>
			<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownmenu">
				<li role="presentation"><a role="menuitem" href="logout.php"><i class="fa fa-circle status-icon signout"></i> Keluar</a></li>
			</ul>
		</div>
	</div>
	<nav class="navigation">
		<ul class="list-unstyled">
			<li><a href="beranda.php"><i class="fa fa-home fa-fw"></i> <span class="nav-label">Beranda</span></a></li>
			<li class="has-submenu">
				<a href="pesan.php"><i class="fa fa-envelope-o fa-fw"></i> <span class="nav-label">Pesan </span>
					<?php
					if($pesan == '') {
					 echo "";
					} else {
					echo "<span class='badge badge-secondary'>1</span>";
					}
					?>
				</a>
			</li>
			<li class="has-submenu"><a href="#"><i class="fa fa-database fa-fw"></i> <span class="nav-label">Server</span></a>
				<ul class="list-unstyled">
					<li><a href="server-member.php"><i class="fa fa-server fa-fw"></i>Member</a></li>
					<li><a href="server-reseller.php"><i class="fa fa-tasks fa-fw"></i>Reseller</a></li>
					<li><a href="server-trial.php"><i class="fa fa-clock-o fa-fw"></i>Trial</a></li>
				</ul>
			</li>
			<li class="has-submenu"><a href="#"><i class="fa fa-terminal fa-fw"></i> <span class="nav-label">Akun SSH</span></a>
				<ul class="list-unstyled">
					<li><a href="akun-member.php"><i class="fa fa-check-circle fa-fw"></i>Member</a></li>
					<li><a href="akun-reseller.php"><i class="fa fa-check-circle-o fa-fw"></i>Reseller</a></li>
					<li><a href="akun.php"><i class="fa fa-circle fa-fw"></i>Semua Akun</a></li>
				</ul>
			</li>
			<li><a href="tambah-saldo.php"><i class="fa fa-money fa-fw"></i> <span class="nav-label">Tambah Saldo</span></a>
			</li>
			<li><a href="unduh-config.php"><i class="fa fa-download fa-fw"></i><span class="nav-label"> Unduh Config</span></a></li>
			<li class="has-submenu"><a href="#"><i class="fa fa-user fa-fw"></i> <span class="nav-label">Profile</span></a>
				<ul class="list-unstyled">
					<li><a href="profile.php"><i class="fa fa-pencil fa-fw"></i> Edit Profile</a></li>
					<li><a href="changepassword.php"><i class="fa fa-key fa-fw"></i> Ganti Password</a></li>
				</ul>
			</li>
			<li><a href="kontak.php"><i class="fa fa-phone-square fa-fw"></i><span class="nav-label"> Kontak</span></a></li>
			<li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i><span class="nav-label"> Keluar</span></a></li>
		</ul>
	</nav>
            
</aside>
<?php 
	} } else {
	header("location: login.php");
}
?>