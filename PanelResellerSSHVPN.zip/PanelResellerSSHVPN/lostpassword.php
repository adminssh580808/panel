<?php
ob_start();
session_start();
include 'asset/css/config.php';
date_default_timezone_set('Asia/Jakarta');
// Waktu Pendaftaran
$waktu1 = date('Y-m-d h:i:s');
// Waktu Jatuh Tempo
$waktu2 = date('Y-m-d', strtotime($waktu1. ' + 5 days'));

// Ambil URL Web
$id = "1";
$qce = "SELECT * FROM site WHERE id = :id";
$ce = $databaseConnection->prepare($qce);
$ce->bindParam(':id', $id);
$ce->execute();
while ($cee = $ce->fetch(PDO::FETCH_OBJ)) {
	$url = $cee->url;
	$emailadmin = $cee->email;
}
// Kode Validasi
function passFunc($len, $set = "") {
$gen = "";
	for($i=0;$i<$len;$i++) {
	$set = str_shuffle($set);
	$gen .= $set[0];
	}
return $gen;
}
$passcode=passFunc(8,'abcdefghijklmnopqrstuvwxyzABCDEFGHIZKLMNOPQRSTUVWXYZ123456789');
// Klik Daftar
if(isset($_POST['tambah'])) {
	
	$email = $_POST['email'];
	$passwordtext = $passcode;
	$password = password_hash($passwordtext, PASSWORD_DEFAULT, ['cost' => 12,]);
	$url = $url;
	
	// Database
	$qcek = "SELECT * FROM member WHERE email = :email";
	$cek = $databaseConnection->prepare($qcek);
	$cek->bindParam(':email', $email);
	$cek->execute();
	// cek email tidak tersedia
	if($cek->rowCount() == 0) {
		$pesan = '
		<div class="alert alert-danger" role="alert">
		<p><b>Email <i>'.$email.'</i> tidak terdaftar</b></p>
		</div>';
	}
	else {
		$qubahpass = "UPDATE member SET password = :password WHERE email = :email";
		$ubahpass = $databaseConnection->prepare($qubahpass);
		$ubahpass->bindParam(':password', $password);
		$ubahpass->bindParam(':email', $email);
		$ubahpass->execute();
		// kirim email
		require_once('function.php');
		$to       = $email;
		$subject  = 'Reset Password';
		$message  = '<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tbody>
		<tr>
		<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
		<td bgcolor="#ffffff" width="660" align="center">
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tbody>
		<tr>
		<td align="center" width="600" valign="top">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tbody>
		<tr>
		<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
		</tr>
		<tr>
		<td bgcolor="#f2f2f2" style="padding-top:10px"></td>
		</tr>
		<tr>
		<td align="center" valign="top" bgcolor="#ffffff">
		<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:20px" width="100%">
		<tbody>
		<tr valign="bottom">    
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<span>
		<b>PERMINTAAN RESET PASSWORD</b>
		</span>                                
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom:10px;padding-top:10px;margin-bottom:10px" width="100%">
		<tbody>
		<tr valign="bottom">    
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td valign="top" style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:15px;line-height:22px;color:#333333">
		<p>Yth. <a href="mailto:'.$email.'" target="_blank">'.$email.'</a>,
		<br>Password Baru Anda : '.$passwordtext.'</p>
		<p>
		Silahkan login :<br>'.$url.' kemudian rubah kembali password Anda demi Keamanan.<br>
		<br><br>Salam Hormat,<br>Admin
		</p>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		</td>
		</tr>
		</tbody>
		</table>
		</td>
		</tr>
		</tbody>
		</table>
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tbody>
		<tr>
		<td align="center" width="600" valign="top">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
		<tbody>
		<tr>
		<td bgcolor="#f2f2f2" style="padding-top:20px"></td>
		</tr>
		<tr>
		<td align="center" valign="top" bgcolor="#f2f2f2">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tbody>
		<tr valign="bottom">   
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<table align="left" border="0" cellpadding="0" cellspacing="0">
		<tbody>
		<tr>
		<td style="font-family:Calibri,Trebuchet,Arial,sans serif;font-size:13px;color:#666;font-weight:bold">
		<span id="m_-6118667421211539915bottomLinks">
		<div style="margin:5px 0;padding:0">
		<span style="display:inline">
		<span>
		<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank">
		Bantuan&nbsp;
		</a>
		</span>
		<span style="color:#ccc"><span> | </span></span>
		<span>
		<a href="https://www.fornesia.com" style="text-decoration:none" target="_blank" >
		Webiste&nbsp;
		</a>
		</span>
		</span>
		</div>
		</span>
		</td>
		</tr>
		</tbody>
		</table>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>    
		</tr>
		</tbody>
		</table>           
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tbody>
		<tr valign="bottom">   
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<p> Jangan balas ke email ini. Untuk menghubungi kami, klik 
		<strong><a href="" style="text-decoration:none" target="_blank" >Bantuan dan Hubungi</a></strong>.
		</p>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>
		</tr>
		</tbody>
		</table>  
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tbody>
		<tr valign="bottom">   
		<td width="20" align="center" valign="top">&nbsp;</td>
		<td>
		<span>  
		<table border="0" cellpadding="0" cellspacing="0" id="m_-6118667421211539915emailFooter" style="padding-top:10px;font:12px Arial,Verdana,Helvetica,sans-serif;color:#292929" width="100%">
		<tbody>
		<tr>
		<td>
		<p>Hak Cipta © 2021 fornesia.com</p>
		</td>
		</tr>
		</tbody>
		</table>
		</span>
		</td>
		<td width="20" align="center" valign="top">&nbsp;</td>    
		</tr>
		</tbody>
		</table>    

		</td>
		</tr>
		</tbody>
		</table>
		</td>

		</tr>
		</tbody>
		</table>
		</td>
		<td bgcolor="#f2f2f2" style="font-size:0px">&nbsp;</td>
		</tr>
		</tbody>
		</table>
		';
		$from_name = 'no reply';
		$from = 'noreply@fornesia.com';
		smtp_mail($to, $subject, $message, $from_name, $from, 0, 0, false);
		$pesan = '
		<div class="alert alert-success" role="alert">
		<p><b>Permintaan Reset Password Berhasil<br>Silahkan chek email Anda.</b></p>
		</div>';
	}
	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include 'base/schema.php'; ?>

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="asset/css/bootstrap/bootstrap.css" /> 

<!-- DateTime Picker  -->
<link rel="stylesheet" href="asset/css/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.css" />

<!-- Fonts  -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

<!-- Bootstrap Validator  -->
<link rel="stylesheet" href="asset/css/bootstrap-validator/bootstrap-validator.css" />

<!-- Base Styling  -->
<link rel="stylesheet" href="asset/css/app/theme.css" />

<title>Reset Password</title>

<script src="asset/js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>

<body style="background-color:#121215">
	<center>
        <div class="warper container-fluid" style="padding: 0;margin:0;min-height:300px;max-width:600px;">
			<div class="row" style="margin:auto">
            	<div class="col-md-offset-2 col-md-8">
				<div class="page-header" style="margin:25px 0 25px"><h1>Reset Password</h1></div>
                	<div class="panel panel-default">
                        <div class="panel-heading">Masukan Email Anda</div>
                        <div class="panel-body">
							<span><?php if (isset($pesan)) { echo $pesan; } ?></span>
                        	<form  method="post" class="validator-form" action="" style="text-align: left">
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
										<input type="text" class="form-control" name="email" placeholder="Ex: email@domain.com" required/>
										</div>
									</div>
								</div>
								<div class="col-md-12" style="padding: 2px">
									<div class="form-group">
									<center>
									<button type="submit" class="btn btn-primary" name="tambah" value="Add" style="width :100%">
										RESET PASSWORD
									</button>
									</center>
									</div>
								</div>
                            </form>
                        </div>
                    </div>
                 </div>
			</div>
       </div>
    </center>
	<?php
	$qtsite = "SELECT * FROM site";
	$tsite = $databaseConnection->prepare($qtsite);
	$tsite->execute();
	$site = $tsite->fetchAll();
	foreach ($site as $site)
	?>
	<p class="text-center">Copyright 2021 <a href="index.php"><b><?php echo $site['name']; ?></b></a></p>

	
	<script id="jsbin-javascript">
		$("input").on("keypress",function(e){
		var val = $(this).val();
		var open = val.indexOf('<');
		var close = val.indexOf('>');
		if(open!==-1 && close!==-1) {
		$(this).val(val.replace(val.slice(open,close+1),""));
		}
		});
	</script>

    <script src="asset/js/plugins/underscore/underscore-min.js"></script>
    <!-- Bootstrap -->
    <script src="asset/js/bootstrap/bootstrap.min.js"></script>
    
    <!-- Globalize -->
    <script src="asset/js/globalize/globalize.min.js"></script>
    
    <!-- NanoScroll -->
    <script src="asset/js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
    
    <!-- moment -->
    <script src="asset/js/moment/moment.js"></script>
    
    <!-- DateTime Picker -->
    <script src="asset/js/plugins/bootstrap-datetimepicker/bootstrap-datetimepicker.js"></script>
    
	<!-- Bootstrap Validator -->
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
    <script src="asset/js/plugins/bootstrap-validator/bootstrapValidator-conf.js"></script>
    
    <!-- Custom JQuery -->
	<script src="asset/js/app/custom.js" type="text/javascript"></script>
    
</body>
</html>